<?php

	if(isset($_SESSION['customer_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
	include_once('header.php');
	?>

  

  <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <h1 class="display-4 text-uppercase text-center mb-5">Edit Profile</h1>
            <div class="row">
                <div class="col-lg-12 mb-2">
                    <div class="contact-form bg-light mb-4" style="padding: 30px;">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row">
								<div class="col-6 form-group">
                                    <input type="text" name="First_name" value="<?php echo $fetch->First_name?>" class="form-control p-4" placeholder="First Name" required="required">
                                </div>
								<div class="col-6 form-group">
                                    <input type="text" name="Last_name" value="<?php echo $fetch->Last_name?>" class="form-control p-4" placeholder="Last Name" required="required">
                                </div>
								<div class="col-6 form-group">
                                    <input type="text" name="Mobile" value="<?php echo $fetch->Mobile?>" class="form-control p-4" placeholder="Your Mobile" required="required">
                                </div>
                               
                                <div class="col-6 form-group">
                                    <input type="email" name="Username" value="<?php echo $fetch->Username?>" class="form-control p-4" placeholder="Your Username" required="required">
                                </div>
                               
								
								<div class="col-6 form-group">
									Pet category:</br>
                                   <select name="Pet_category" class="form-control">
								   <option value="">---Select Category---</option>
										<?php
										foreach($category_arr as $c)
										{
											if($fetch->Pet_category==$c->cate_name)
											{
										?>
											<option value="<?php echo $c->cate_name;?>" selected> <?php echo $c->cate_name;?></option>
										<?php
											}
											else
											{
										?>
											<option value="<?php echo $c->cate_name;?>"> <?php echo $c->cate_name;?></option>
										<?php
										
											}
										}
										?>
								   </select>
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="text"  name="Pet_name" value="<?php echo $fetch->Pet_name?>" class="form-control p-4" placeholder="Pet Name" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="text"  name="Pet_age" value="<?php echo $fetch->Pet_age?>" class="form-control p-4" placeholder="Pet Age" required="required">
                                </div>
								
								<div class="col-12 form-group">
									Pet Gender:</br>
									<?php
									$Pet_gender=$fetch->Pet_gender;
									if($Pet_gender=="Male")
									{
									?>
										Male: <input type="radio" name="Pet_gender"  value="Male" checked>
										Female: <input type="radio" name="Pet_gender"  value="Female">
									<?php
									}
									else
									{
									?>
										Male: <input type="radio" name="Pet_gender"  value="Male" >
										Female: <input type="radio" name="Pet_gender"  value="Female" checked>
									<?php
									}
									?>	
                                </div>
								
								
								<div class="col-12 form-group">
									Upload pet profile:</br>
                                    <input type="file"  name="Upload_pet_profile" class="form-control" >
									<img src="img/vineeta/<?php echo $fetch->Upload_pet_profile?>" width="100px">
                                </div>
                            </div>
							<div>
                                <input class="btn btn-primary py-3 px-5" type="submit" name="update" value="Save">
								
                            </div>
                            
                            
                        </form>
                    </div>
                </div>
          
            </div>
        </div>
    </div>
    <!-- Contact End -->


<?php
   include_once('footer.php')
   ?>