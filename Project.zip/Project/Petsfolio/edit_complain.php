
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pet Clinic | Add Complain</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/style.css">
  <style>
    /* Add specific styles for your 'add_complain.php' page here */
    body {
      margin: 0;
      padding: 0;
      font-family: 'Arial', sans-serif;
    }

    #content {
      margin: 20px; /* Adjust margin as needed */
    }

    .complain-form {
      max-width: 600px; /* Set the maximum width of the form */
      margin: 0 auto;
    }

    .complain-form label {
      display: block;
      margin-bottom: 8px;
    }

    .complain-form input,
    .complain-form textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }

    .complain-form button {
      background-color: #2ecc71;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .complain-form button:hover {
      background-color: #27ae60;
    }
  </style>
 </head>
 
 <body>
<!-- Include your header.php -->
  <?php include('header.php'); ?>

  <!-- Content -->
  <section id="content">
    <div class="complain-form">
      <h2>Edit Complain</h2>
      <div class="panel-body">
                            
								<form method="post" >
                            <div class="row">
							
								<div class="col-6 form-group">
                                    <input type="text" name="Note" value="<?php echo $fetch->Note?>" class="form-control p-4" placeholder="Your Note" required="required">
                                </div>
								<div class="col-6 form-group">
                                    <input type="text" name="Rate" value="<?php echo $fetch->Rate?>" class="form-control p-4" placeholder="Your Rate" required="required">
                                </div>
								<div class="col-6 form-group">
									Select Doctor :</br>
                                   <select name="Doctor_id" class="form-control">
                                    <option value="">Not Selected</option>
										<?php
										foreach($doct_arr as $c)
										{
											if($fetch->Doctor_id==$c->Name)
											{
										?>
											<option value="<?php echo $c->Name;?>" selected> <?php echo $c->Name;?></option>
										<?php
											}
											else
											{
										?>
											<option value="<?php echo $c->Name;?>"> <?php echo $c->Name;?></option>
										<?php
										
											}
										}
										?>
								   </select>
                                </div>
								
			<div>
               <input class="btn btn-primary py-3 px-3" type="submit" name="update" value="submit">
			   

          </div>
      </form>
    </div>
  </section>
</body>
</html>

<?php
   include_once('footer.php')
   ?>