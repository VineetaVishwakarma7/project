﻿<?php
// Check if the user is not logged in
if (!isset($_SESSION['customer_id'])) {
    // Redirect the user to the login page
    header("Location: login");
    exit(); // Stop further execution
}

include_once('header.php');
include_once('../Admin/model.php'); // Include the model file

// Check if Doctor_id is provided in the URL
if (isset($_GET['Doctor_id'])) {
    $Doctor_id=$_GET['Doctor_id'];
    $obj = new model;
    $pres_arr = $obj->select_where('prescription', array("Doctor_id" => $Doctor_id));
} else {
    echo "Doctor ID not provided!";
}

?>
		<div id="page-wrapper">
            <div id="page-inner">
                      <div class="container py-5">
            <div class="d-flex flex-column text-center mb-12">
                <h1 class="display-4 m-0"><span class="text-primary">Prescription</h1>
            </div>
    </div>                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-12">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
											<th>Old_prescription</th>
                                            <th>customer_id</th>
                                            
											
                                        </tr>
                                    </thead>
                                    <tbody>

										<?php
										if(!empty($pres_arr))
											{
											foreach($pres_arr as $c)
											{
										?>						
                                        <tr>
											
                                            <td><?php echo $c['Old_prescription'] ?></td>
                                            <td><?php echo $c['customer_id'] ?></td>

     
                                        </tr>
										<?php
											}
										} 
										else {
											echo "No Prescription found for this doctor";
											 }
										?>
										</tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>
