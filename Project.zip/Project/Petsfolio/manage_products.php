﻿<?php
// Check if the user is not logged in
if (!isset($_SESSION['customer_id'])) {
    // Redirect the user to the login page
    header("Location: login");
    exit(); // Stop further execution
}

include_once('header.php');
include_once('../Admin/model.php'); // Include the model file

// Check if Doctor_id is provided in the URL
if (isset($_GET['Doctor_id'])) {
    $Doctor_id=$_GET['Doctor_id'];
    $obj = new model;
    $prod_arr = $obj->select_where('product', array("Doctor_id" => $Doctor_id));
} else {
    echo "Doctor ID not provided!";
}

?>
                
 <!-- Products Start -->
        <div class="container py-5">
            <div class="d-flex flex-column text-center mb-12">
                <h1 class="display-4 m-0"><span class="text-primary">Pet</span> Products</h1>
            </div>
		
    </div>
			
<div class="container">
    <div class="row">
				<?php
				if(!empty($prod_arr))
					{
					foreach($prod_arr as $c)
					{
				?>	
                <div class="col-lg-4 mb-4">
                    <div class="card">
                    <div class="d-flex flex-column text-center bg-white mb-2 p-3 p-sm-5">
                        <h3 class="font-weight-normal text-secondary mb-3"><td><img src="img/vineeta/<?php echo $c['p_img']?>"width="250px"></td></h3>
                        <h3 class="mb-3"><td><?php echo $c['Product_name']?></td></h3>
                        <p><td><?php echo $c['Product_category']?></td></p>
						<p><b>Price:<td><?php echo $c['Price']?></td>/-</b></p>
                        <a href="" class="btn btn-primary"><?php echo $c['status']?></a>
                    </div>
                </div>
            </div>
			<?php
				}
				} 
				else {
				echo "No Products found for this doctor";
				 }
			?>
	    </div>
    </div>
	
    <!-- Products End -->

  <?php
   include_once('footer.php')
   ?>