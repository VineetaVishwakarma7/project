﻿<?php
// Check if the user is not logged in
if (!isset($_SESSION['customer_id'])) {
    // Redirect the user to the login page
    header("Location: login");
    exit(); // Stop further execution
}

include_once('header.php');
include_once('../Admin/model.php'); // Include the model file

// Check if Doctor_id is provided in the URL
if (isset($_GET['Doctor_id'])) {
    $Doctor_id=$_GET['Doctor_id'];
    $obj = new model;
    $serv_arr = $obj->select_where('services', array("Doctor_id" => $Doctor_id));
} else {
    echo "Doctor ID not provided!";
}

?>	
	<?php
   include_once('header.php')
   ?>
                
 <!-- Services Start -->
        <div class="container py-5">
            <div class="d-flex flex-column text-center mb-12">
                <h1 class="display-4 m-0"><span class="text-primary">Pet</span> Services</h1>
            </div>
	
    </div>
			
<div class="container">
    <div class="row">
				<?php
				if(!empty($serv_arr))
					{
					foreach($serv_arr as $c)
					{
				?>	
                <div class="col-lg-4 mb-4">
                    <div class="card">
                    <div class="d-flex flex-column text-center bg-white mb-2 p-3 p-sm-5">
                        <h3 class="flaticon-vaccine display-3 font-weight-normal text-secondary mb-3"></h3>
                        <h3 class="mb-3"><td><?php echo $c['service_name'] ?></td></h3>
                        <p><b>Price:<td><?php echo $c['price'];?></td>/-</b></p>
						<p><td><?php echo $c['detail'];?></td></p>
                    </div>
                </div>
            </div>
			<?php
				}
				} 
				else {
					echo "No Prescription found for this doctor";
					}
				?>
        
	    </div>
    </div>
	
    <!-- Services End -->

  <?php
   include_once('footer.php')
   ?>