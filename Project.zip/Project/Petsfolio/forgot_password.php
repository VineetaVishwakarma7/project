<?php 
include_once('header.php'); 
?>
<?php
	if(isset($_SESSION['customer_id']))
	{
		echo "<script>
			window.location='index';
		</script>";
	}
	?>
<div class="container-fluid py-5">
    <div class="container pt-5 pb-3">
        <h1 class="display-4 text-uppercase text-center mb-5">Forgot Password</h1>
        <div class="row">
            <div class="col-lg-12 mb-2">
                <div class="contact-form bg-light mb-6" style="padding: 30px;">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-12 form-group">
                                <input type="email" name="Username" id="email" class="form-control p-4" placeholder="Your Email" required="required">
                            </div>
                        </div>
                        <div class="row">
                         <input class="btn btn-primary py-3 px-5" name="submit" type="submit" value="Send Verification Link">
                           
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once('footer.php'); ?>