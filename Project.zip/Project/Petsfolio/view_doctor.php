<?php
include_once('header.php');
?>
 <div class="container py-5">
            <div class="d-flex flex-column text-center mb-12">
                <h1 class="display-4 m-0"><span class="text-primary">Pet</span> Doctors</h1>
            </div>
	
    </div>

<div class="container">
    <div class="row">
        <?php
        if (!empty($doct_arr)) {
            foreach ($doct_arr as $c) {
        ?>
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <img class="card-img-top" src="img/vineeta/<?php echo $c->Upload_profile; ?>" alt="Doctor Image" style="height: 200px;">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $c->Name; ?></h5>
							<h6 class="card-text">Clinic: <?php echo $c->name_of_hospital; ?></h6>
                            <h6 class="card-text">Mobile: <?php echo $c->Mobile; ?></h6>
                            <h6 class="card-text">Email: <?php echo $c->Username; ?></h6>
							 <h6 class="card-text">Location of Hospital: 
								<a href="https://www.google.com/maps?q=<?php echo $c->Location_hospital; ?>,<?php echo $c->Location_hospital; ?>" target="_blank">
									<span class="text-secondary"><?php echo $c->Location_hospital; ?></span>
								</a>
							</h6>
                            <h6 class="card-text">Consulting Fees: <?php echo $c->cfees; ?></h6>
                            <h6 class="card-text">Followup Fees: <?php echo $c->ffees; ?></h6>
                            <a href="doctor_profile?Doctor_id=<?php echo $c->Doctor_id; ?>" class="btn btn-primary">View Profile</a>
							
                        </div>
                    </div>
                </div>
        <?php
            }
        }
        ?>
    </div>
</div>

<?php
include_once('footer.php');
?>
