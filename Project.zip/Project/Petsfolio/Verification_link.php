<?php
	include_once('header.php');
	?>
  
  <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <h1 class="display-4 text-uppercase text-center mb-5">Varification required</h1>
            <div class="row">
                <div class="col-lg-12 mb-2">
                    <div class="contact-form bg-light mb-6" style="padding: 30px;">
                       <form action="" method="post" enctype="multipart/form-data">
                            <div class="row">
								<div class="col-6 form-group">
                                    <input type="otp" name="Otp" class="form-control p-4" placeholder="Enter Otp" required="required">
                                </div>
                          <div>
                                <input class="btn btn-primary py-3 px-5" name="login" type="submit" value="Send Password Reset Link">
								
                            </div>
                        </form>
                    </div>
                </div>
          
            </div>
        </div>
    </div>
    <!-- Contact End -->


<?php
   include_once('footer.php')
   ?>