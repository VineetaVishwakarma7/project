﻿<?php
// Check if the user is not logged in
if (!isset($_SESSION['customer_id'])) {
    // Redirect the user to the login page
    header("Location: login");
    exit(); // Stop further execution
}

include_once('header.php');
include_once('../Admin/model.php'); // Include the model file

// Check if Doctor_id is provided in the URL
if (isset($_GET['Doctor_id'])) {
    $Doctor_id=$_GET['Doctor_id'];
    $obj = new model;
    $slot_arr = $obj->select_where('slots', array("Doctor_id" => $Doctor_id));
} else {
    echo "Doctor ID not provided!";
}

?>



		<div id="page-wrapper">
            <div id="page-inner">
                <div class="container py-5">
            <div class="d-flex flex-column text-center mb-12">
                <h1 class="display-4 m-0"><span class="text-primary">Appointment</span> Slots</h1>
            </div>
    </div>
	<!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
											<th>Time</th>
											<th align="center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
										if(!empty($slot_arr))
										{
											foreach($slot_arr as $c)
											{
										?>
										<tr>
                                            <td><?php echo $c['Time'] ?></td>

										<td align="center">	
											<form action="Booked_appointment" method="post"> 
											  <input type="hidden" name="customer_id" value="<?php echo $_SESSION['customer_id']?>">
											  <input type="hidden" name="slot_id" value="<?php echo $c['slot_id']?>">
											  <input type="hidden" name="Doctor_id" value="<?php echo $c['Doctor_id']?>">
											  <input type="hidden" name="Time" value="<?php echo $c['Time']?>">
											  <input type="date" name="Date" required /> 
											<input type="submit" name="booked" class="btn btn-primary" value="booked">	
											
											</form>

										   
										  
										</td>

										
									</tr>
										<?php
											}
										} 
										else {
											echo "No slots found for this doctor";
											 }
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>