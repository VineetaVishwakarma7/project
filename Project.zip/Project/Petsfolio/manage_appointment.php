﻿	﻿<?php
// Check if the user is not logged in
if (!isset($_SESSION['customer_id'])) {
    // Redirect the user to the login page
    header("Location: login");
    exit(); // Stop further execution
}
?>
	
	<?php
   include_once('header.php')
   ?>
   <?php
  if (isset($_SESSION['customer_id'])) {
    $customer_id=$_SESSION['customer_id'];
    $obj = new model;
    $appo_arr = $obj->select_where('appointment', array("customer_id" => $customer_id));
} else {
    echo "CUSTOMER ID not provided!";
}
?>
		<div id="page-wrapper">
            <div id="page-inner">
        <div class="container py-5">
            <div class="d-flex flex-column text-center mb-12">
                <h1 class="display-4 m-0"><span class="text-primary">Book</span> Appointment</h1>
            </div>
		</div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Time</th>
                                            <th>Date</th>
                                        <th align="center">Action</th>
											
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php
										if(!empty($appoi_arr))
										{
											foreach($appoi_arr as $c)
											{
										?>
										<tr>
											<td><?php echo$c->Time?></td>
                                            <td><?php echo$c->Date?></td>
											<td align="center">
                                         <a href="status?status_appointment_id=<?php echo $c->appointment_id; ?>" class="btn btn-primary"><?php echo $c->status; ?></a>
                                             </td>
                                        </tr>
										<?php
										}
										}
										?>
													
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>