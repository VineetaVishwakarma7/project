<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pet Clinic | Add Complain</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/style.css">
  <style>
    /* Add specific styles for your 'add_complain.php' page here */
    body {
      margin: 0;
      padding: 0;
      font-family: 'Arial', sans-serif;
    }

    #content {
      margin: 20px; /* Adjust margin as needed */
    }

    .complain-form {
      max-width: 600px; /* Set the maximum width of the form */
      margin: 0 auto;
    }

    .complain-form label {
      display: block;
      margin-bottom: 8px;
    }

    .complain-form input,
    .complain-form textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }

    .complain-form button {
      background-color: #2ecc71;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .complain-form button:hover {
      background-color: #27ae60;
    }
  </style>
 </head>
 
 <body>
<!-- Include your header.php -->
  <?php
if(isset($_SESSION['customer_id']))
{
    
}
else
{
    echo "<script>
        window.location='index';
    </script>";
}
  include('header.php'); 
  ?>

  <!-- Content -->
  <section id="content">
    <div class="complain-form">
	                <div class="container py-5">
	  <div class="d-flex flex-column text-center mb-12">
      <h1 class="display-4 m-0"><span class="text-primary">Add</span> Complain</h1>
	  </div>
	  </div>
      <div class="panel-body">
                            
								<form method="post" >
                            <div class="row">
								<div class="col-12 form-group">
                                    <input type="hidden" name="First_name" value="<?php echo $_SESSION['First_name']?>">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="text" Name="Note" class="form-control p-4" placeholder="Your Note" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="Rate" name="Rate"  class="form-control p-4" placeholder="Your Rate" required="required">
                                </div>
								
								<div class="col-12 form-group">
									Select Doctor :</br>
                                   <select name="Doctor_id" class="form-control">
                                    <option value="">Not Selected</option>
										<?php
										foreach($doct_arr as $c)
										{
										?>
										<option value="<?php echo $c->Name;?>"> <?php echo $c->Name;?> </option>
										<?php
										}
										?>
								   </select>
                                </div>
			<div>
               <input class="btn btn-primary py-3 px-0" type="submit" name="submit" value="submit">
			   <a href="manage_complain"  style="float:right">Manage complain</a>
                  
          </div>
      </form>
    </div>
  </section>
</body>
</html>

<?php
   include_once('footer.php')
   ?>