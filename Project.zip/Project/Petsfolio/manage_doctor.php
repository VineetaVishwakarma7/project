		<?php
   include_once('header.php')
   ?>
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Contacts</h1>

                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-12">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Doctor Contacts
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Doctor_id</th>
                                            <th>Name</th>
                                            <th>Mobile</th>
                                            <th>gender</th>
                                            <th>Upload_profile</th>
											<th>License_doctor</th>
											<th>Location_hospital</th>
                                            <th>Username</th>
											
											<th align="center">Action</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									if(!empty($doct_arr))
									{
										foreach($doct_arr as $c)
										{
									?>						
                                        <tr>
                                            <td><?php echo $c->Doctor_id;?></td>
                                            <td><?php echo $c->Name;?></td>
                                            <td><?php echo $c->Mobile;?></td>
											<td><?php echo $c->gender;?></td>
											<td><img src="img/vineeta/<?php echo $c->Upload_profile;?>"width="50px"></td>
											<td><img src="img/vineeta/<?php echo $c->License_doctor;?>"width="50px"></td>
											<td><?php echo $c->Location_hospital;?></td>
											<td><?php echo $c->Username;?></td>
											
										<td align="center">
										<a href="status?status_Doctor_id=<?php echo $c->Doctor_id ;?>" class="btn btn-primary"><?php echo $c->status;?></a>										
										</td>
                                        </tr>
										<?php
										}
									}
									?>
									
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>