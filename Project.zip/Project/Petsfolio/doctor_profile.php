<?php
include_once('header.php');
?>

<div class="container">
<?php


if(isset($_GET['Doctor_id'])) {
    $_SESSION['current_doctor_id'] = $_GET['Doctor_id'];
	$Doctor_id = $_GET['Doctor_id'];
    $query = "SELECT * FROM doctor WHERE Doctor_id = $Doctor_id";
}
?>

    <div class="row">
        <div class="col-md-6 ">
             <div class="container py-5">
            <div class="d-flex flex-column text-center mb-6">
                <h1 class="display-4 m-0"><span class="text-primary">Doctor</span> Profile</h1>
            </div>
			</div>
			<img class="card-img-top" src="img/vineeta/<?php echo $doctor_profile->Upload_profile; ?>" alt="Doctor Image" style="height: 200px;" "width: 300px;" >
            <p>Name: <?php echo $doctor_profile->Name; ?></p>
            <p>Clinic: <?php echo $doctor_profile->name_of_hospital; ?></p>
            <p>Mobile: <?php echo $doctor_profile->Mobile; ?></p>
			<p>Email: <?php echo $doctor_profile->Username; ?></p>
			<p>Consulting Fees: <?php echo $doctor_profile->cfees; ?></p>
			<p>Followup Fees: <?php echo $doctor_profile->ffees; ?></p>
			<p>Location of Hospital: <?php echo $doctor_profile->Location_hospital; ?></p>
			</div>
             <div class="col-md-6 ">
            <div class="container py-5 text-center">
         </div>
			
				<!-- Doctor Profile Page -->
				 <div class="container py-3" align="Center">
			<a href="Appointment_slots?Doctor_id=<?php echo $Doctor_id; ?>" class="btn btn-primary py-3 px-5">View Doctor Slots</a>
			</div>
			
				 <div class="container py-3" align="Center">
			<a href="Products?Doctor_id=<?php echo $Doctor_id; ?>" class="btn btn-primary py-3 px-5">View Pet Products</a></br>
			</div>
			
				
				 <div class="container py-3" align="Center">
            <a href="Services?Doctor_id=<?php echo $Doctor_id; ?>" class="btn btn-primary py-3 px-5">View Pet Services</a>
			</div>
			 <div class="container py-3" align="Center">
            <a href="Prescription?Doctor_id=<?php echo $Doctor_id; ?>" class="btn btn-primary py-3 px-5">View Prescription</a>
			</div>
			
        </div>
    </div>

<?php
include_once('footer.php');
?>