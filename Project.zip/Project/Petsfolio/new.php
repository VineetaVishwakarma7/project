

  <!-- Include your header.php -->
  <?php include('header.php'); ?>

  <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <h1 class="display-4 text-uppercase text-center mb-5">Signup</h1>
            <div class="row">
                <div class="col-lg-12 mb-2">
                    <div class="contact-form bg-light mb-4" style="padding: 30px;">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row">
								<div class="col-12 form-group">
                                    <input type="text" name="name" class="form-control p-4" placeholder="Your Name" required="required">
                                </div>
                               
                                <div class="col-6 form-group">
                                    <input type="text" name="unm" class="form-control p-4" placeholder="Your Username" required="required">
                                </div>
                                <div class="col-6 form-group">
                                    <input type="password"  name="pass" class="form-control p-4" placeholder="Your password" required="required">
                                </div>
								
								<div class="col-12 form-group">
									Gender:</br>
                                    Male: <input type="radio" name="gen"  value="Male">
									Female: <input type="radio" name="gen"  value="Female">
                                </div>
								
								
								<div class="col-12 form-group">
									profile:</br>
                                    <input type="file"  name="profile" class="form-control" required="required">
                                </div>
                            </div>
                            
                            <div>
                                <input class="btn btn-primary py-3 px-5" type="submit" name="submit" value="Signup">
								<a href="login" style="float:right">Login</a>
                            </div>
                        </form>
                    </div>
                </div>
          
            </div>
        </div>
    </div>
    <!-- Contact End -->


<?php
   include_once('footer.php')
   ?>