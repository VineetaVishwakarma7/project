	<?php
   include_once('header.php')
   ?>
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="container py-5">
            <div class="d-flex flex-column text-center mb-12">
                <h1 class="display-4 m-0"><span class="text-primary">Manage</span> Complain</h1>
            </div>
    </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Note</th>
                                            <th>Rate</th>
											<th>Customer name</th>
											<th>Doctor name</th>
                                            <th align="center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
										if(!empty($comp_arr))
										{
											foreach($comp_arr as $c)
											{
										?>
										<tr>
                                            <td><?php echo$c->Note?></td>
                                            <td><?php echo$c->Rate?></td>
											<td><?php echo$c->First_name?></td>
											<td><?php echo$c->Doctor_id?></td>
                                   		<td align="center">
										<a href="edit_complain?edit_complain_id=<?php echo $c->complain_id;?>" class="btn btn-info">Edit</a>
										<a href="delete?del_complain_id=<?php echo $c->complain_id;?>" class="btn btn-danger">Delete</a>
										</td>
                                        </tr>
										<?php
											}
										}
										?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>