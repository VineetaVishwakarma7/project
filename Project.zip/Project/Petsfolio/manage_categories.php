﻿	<?php
   include_once('header.php')
   ?>
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage Categories</h1>
                        
						</div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-12">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manage Categories
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>cate_id</th>                                           
                                            <th>cate_name</th>
                                            <th>cate_image</th>
											<th>Action</th>
											
											
										</tr>
                                    </thead>
                                    <tbody>
										<?php
										if(!empty($cate_arr))
										{
											foreach($cate_arr as $c)
											{
										?>
										<tr>
                                            <td><?php echo$c->cate_id?></td>
                                            <td><?php echo$c->cate_name?></td>
                                            <td><?php echo$c->cate_img?></td>
										<td>
										<a href="#" class="btn btn-info">Edit</a>
										<a href="delete?del_cate_id=<?php echo $c->cate_id;?>" class="btn btn-danger">Delete</a>
										</td>
                                        </tr>
										<?php
										}
										}
										?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>