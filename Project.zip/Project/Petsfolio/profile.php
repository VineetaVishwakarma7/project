<?php
   include_once('header.php')
   ?>
   <div class="container-fluid py-5">
        <div class="container py-5">
            <h4 class="display-4 text-uppercase text-center mb-5">Profile</h4>
            <div  style="padding: 0 30px;">
                <div class="text-center">
                    <img width="300px" src="img/vineeta/<?php echo $data->Upload_pet_profile?>" alt="">
                    <div class=" py-4">
                        <p class="m-0">First_name: <?php echo $data->First_name?></p>
						<p class="m-0">Last_name : <?php echo $data->Last_name?></p>
						<p class="m-0">Mobile : <?php echo $data->Mobile?></p>
						<p class="m-0">Username : <?php echo $data->Username?></p>
						<p class="m-0">Pet_category: <?php echo $data->Pet_category?></p>
						<p class="m-0">Pet_name: <?php echo $data->Pet_name?></p>
						<p class="m-0">Pet_age: <?php echo $data->Pet_age?></p>
						<p class="m-0">Pet_gender: <?php echo $data->Pet_gender?></p>
						<a href="edit_user?edit_customer_id=<?php echo $data->customer_id ;?>" class="btn btn-primary">Edit</a>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
			
<?php
   include_once('footer.php')
   ?>