<?php
    if(isset($_SESSION['customer_id'])) {
        echo "<script>window.location='index';</script>";
    }

    include_once('header.php');

    // Check if the login form is submitted
    if(isset($_POST['login'])) {
        // Handle login process here
    }
?>
  
<!-- Contact Start -->
<div class="container-fluid py-5">
    <div class="container pt-5 pb-3">
        <h1 class="display-4 text-uppercase text-center mb-5">Login</h1>
        <div class="row">
            <div class="col-lg-12 mb-2">
                <div class="contact-form bg-light mb-6" style="padding: 30px;">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-6 form-group">
                                <input type="email" name="Username" class="form-control p-4" value="<?php if(isset($_COOKIE['emailcookie'])) { echo $_COOKIE['emailcookie'];}?>" placeholder="Your Username" required="required">
                            </div>
                            <div class="col-6 form-group">
                                <div class="input-group">
                                    <input type="password" id="passwordInput" name="Password" class="form-control p-4" value="<?php if(isset($_COOKIE['passcookie'])) { echo $_COOKIE['passcookie'];}?>" placeholder="Your Password" required="required">
                                    <div class="input-group-append">
                                        <span class="input-group-text" id="togglePassword">
                                            <i class="fa fa-eye" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <input class="btn btn-primary py-3 px-5" name="login" type="submit" value="Login">
                            <a href="signup" style="float:right">New User? Click Here for Registration</a>
                            <a href="forgot_password" style="float:end">Forgot Password?</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Contact End -->

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var togglePassword = document.getElementById('togglePassword');
        var passwordInput = document.getElementById('passwordInput');

        togglePassword.addEventListener('click', function() {
            var type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.querySelector('i').classList.toggle('fa-eye');
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    });
</script>

<?php
    include_once('footer.php');
?>