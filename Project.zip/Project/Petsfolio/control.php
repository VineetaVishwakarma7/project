<?php

      include_once('../Admin/model.php');  // 1 step load model


class control extends model  //  2 step extends model
{
	function __construct()
	{
		require 'phpmailer/PHPMailerAutoload.php';
		model::__construct(); // 3 step call model __construct()
		session_start();
		$url=$_SERVER['PATH_INFO'];
		
		switch($url)
		{
			case '/about':
			include_once('about.php');
			break;
			
			case '/add_complain':
			$doct_arr=$this->select('doctor');
			if(isset($_REQUEST['submit']))
			{
				$First_name=$_REQUEST['First_name'];
				$Note=$_REQUEST['Note'];
				$Rate=$_REQUEST['Rate'];
				$Doctor_id=$_REQUEST['Doctor_id'];
				
				$arr_data=array("First_name"=>$First_name,"Note"=>$Note,"Rate"=>$Rate,"Doctor_id"=>$Doctor_id);
				
				$res=$this->insert('complain',$arr_data);
				if($res)
				{
					echo"<script>
					    alert('Register success !');
				    </script>";
				}
				else
				{
					echo"error";
				}
			
			}
			include_once('add_complain.php');
			break;
			
			case '/edit_complain':
			$doct_arr=$this->select('doctor');
			if(isset($_REQUEST['edit_complain_id']))
			{
				$complain_id=$_REQUEST['edit_complain_id'];
				$where=array("complain_id"=>$complain_id);
				
				$res=$this->select_where('complain',$where);
				$fetch=$res->fetch_object();
				
				if(isset($_REQUEST['update']))
				{
					$Note=$_REQUEST['Note'];
					$Rate=$_REQUEST['Rate'];
					$Doctor_id=$_REQUEST['Doctor_id'];
					
					$arr_data=array("Note"=>$Note,"Rate"=>$Rate,"Doctor_id"=>$Doctor_id);
						
						$res=$this->update('complain',$arr_data,$where);
						if($res)
						{
							echo "<script>
								alert('Update success !');
								window.location='add_complain';
							</script>";
						}
						else
						{
							echo "<script>
								alert('Error');
								window.location='add_complain';
							</script>";
						}
				}
			}
			include_once('edit_complain.php');
			break;
			
			case '/manage_complain':
			$comp_arr=$this->select('complain');
			include_once('manage_complain.php');
			break;
			
			
			case '/contacts':
			$doct_arr=$this->select('doctor');
			include_once('manage_doctor.php');
			break;
			
			case '/index':
			include_once('index.php');
			break;
			
			case '/login':
			if(isset($_REQUEST['login']))
			{
				
				$Username=$_REQUEST['Username'];
				$passe=$_REQUEST['Password'];
				$Password=md5($passe); // enc pass
				
				$where=array("Username"=>$Username,"Password"=>$Password);
				
				$res=$this->select_where('customer' ,$where);
				$chk=$res->num_rows; // check fetch data by rows
				if($chk==1)
				{
					// session create
					$fetch=$res->fetch_object();
					
					if($fetch->status=="Unblock")
					{
					    $_SESSION['customer_id']=$fetch->customer_id;
						$_SESSION['Username']=$fetch->Username;
						$_SESSION['First_name']=$fetch->First_name;
						
						// cookie create 		
						if(isset($_REQUEST['rem']))
							{
								setcookie('emailcookie',$Username,time()+30);
								setcookie('passcookie',$passe,time()+30);
							}	
						echo "<script>
							alert('Login success !');
							window.location='index';
						</script>";
					}
					else
					{
						echo "<script>
							alert('Login Failed due to account Blocked !');
						</script>";
					}
				}
				else
				{
						echo "<script>
							alert('Login Failed due to Wrong Creadential! ');
						</script>";
				}				
				
			}
			include_once('login.php');
			break;
			
			case '/profile':
			if(isset($_SESSION['customer_id']))
			{
				$arr=array('customer_id'=>$_SESSION['customer_id']);
				$res=$this->select_where('customer' ,$arr);
				$data=$res->fetch_object();
				include_once('profile.php');
			}
			else
			{
				echo "<script>
					window.location='index';
				</script>";
			}
			break;
			
			case '/edit_user':
			$category_arr=$this->select('category');
			if(isset($_REQUEST['edit_customer_id']))
			{
				$customer_id=$_REQUEST['edit_customer_id'];
				$where=array("customer_id"=>$customer_id);
				
				$res=$this->select_where('customer',$where);
				$fetch=$res->fetch_object();
				// if user update img then delete old image
				$oldimg=$fetch->Upload_pet_profile;
				
				if(isset($_REQUEST['update']))
				{
					$First_name=$_REQUEST['First_name'];
					$Last_name=$_REQUEST['Last_name'];
					$Mobile=$_REQUEST['Mobile'];
					$Username=$_REQUEST['Username'];
					$Pet_category=$_REQUEST['Pet_category'];
					$Pet_name=$_REQUEST['Pet_name'];
					$Pet_age=$_REQUEST['Pet_age'];
					$Pet_gender=$_REQUEST['Pet_gender'];
					
					//img upload
					if($_FILES['Upload_pet_profile']['size']>0)
					{
						$Upload_pet_profile=$_FILES['Upload_pet_profile']['name'];
						$path='img/vineeta/'.$Upload_pet_profile;
						$img_file=$_FILES['Upload_pet_profile']['tmp_name'];
						move_uploaded_file($img_file,$path);
					
						$arr_data=array("First_name"=>$First_name,'Last_name'=>$Last_name,'Mobile'=>$Mobile,"Username"=>$Username,"Pet_category"=>$Pet_category,"Pet_name"=>$Pet_name,"Pet_age"=>$Pet_age,"Pet_gender"=>$Pet_gender,"Upload_pet_profile"=>$Upload_pet_profile);
						
						$res=$this->update('customer' ,$arr_data,$where);
						if($res)
						{
							unlink('img/vineeta/'.$oldimg); // 	delete old img
							echo "<script>
								alert('Update success !');
								window.location='profile';
							</script>";
						}
					}
					else
					{
						$arr_data=array("First_name"=>$First_name,'Last_name'=>$Last_name,'Mobile'=>$Mobile,"Username"=>$Username,"Pet_category"=>$Pet_category,"Pet_name"=>$Pet_name,"Pet_age"=>$Pet_age,"Pet_gender"=>$Pet_gender);
						
						$res=$this->update('customer' ,$arr_data,$where);
						if($res)
						{
							echo "<script>
								alert('Update success !');
								window.location='profile';
							</script>";
						}
					}
				}	
			}
			include_once('edit_user.php');
			break;
			
			case '/logout':
			unset($_SESSION['customer_id']);
			echo "<script>
					alert('Logout success !');
					window.location='index';
				</script>";
			break;
			
			case '/Booked_appointment':
			$appoi_arr=$this->select('appointment');
			$doctor_arr=$this->select('doctor');
			if(isset($_REQUEST['booked']))
			{
				$customer_id=$_REQUEST['customer_id'];
				$slot_id=$_REQUEST['slot_id'];
				$Doctor_id=$_REQUEST['Doctor_id'];
				$Date=$_REQUEST['Date'];
				$Time=$_REQUEST['Time'];
				
				$where=array("slot_id"=>$slot_id,"Doctor_id"=>$Doctor_id,"Date"=>$Date);
				
				$res=$this->select_where('appointment',$where);
				$chk=$res->num_rows; // check fetch data by rows
				if($chk==1)
				{
					$fetch=$res->fetch_object();
					if($fetch->status=="Booked")
					{
						echo "<script>
									alert('Already Booked !');
									window.history.back();
								</script>";
					}
				}
				else
				{	
					$arr_data=array("customer_id"=>$customer_id,"slot_id"=>$slot_id,"Doctor_id"=>$Doctor_id,"Date"=>$Date,"Time"=>$Time);
					$res=$this->insert('appointment',$arr_data);
					if($res)		
					{
						echo "<script>
							alert('inquiry Subbmited success !');
						</script>";
					}
					else
					{
						echo "error";
					}	
				}
			}
			include_once('manage_appointment.php');
			break;
			
			case '/Appointment_slots':
			$slot_arr=$this->select('slots');
            include_once('manage_appointment_slots.php');
			break;
			
			case '/Prescription':
			$pres_arr=$this->select('prescription');
			include_once('manage_prescription.php');
			break;
			
			case '/Services':
			$serv_arr=$this->select('services');
			include_once('manage_services.php');
			break;	

			case '/Products':
			$prod_arr=$this->select('product');
			include_once('manage_products.php');
			break;	

			case '/view_doctor':
			$doct_arr = $this->select('doctor');
			include_once('view_doctor.php');
			break;

           case '/doctor_profile':
			if(isset($_GET['Doctor_id'])) {
			// Sanitize the Doctor_id parameter
			$Doctor_id=filter_var($_GET['Doctor_id'], FILTER_SANITIZE_NUMBER_INT);
        
			// Fetch the doctor's profile from the database based on the Doctor_id
			$where=array("Doctor_id"=>$Doctor_id);
			$res=$this->select_where('doctor',$where);
			$doctor_profile=$res->fetch_object();
			
			
			
			// Check if the profile exists
			if($doctor_profile) {
            // Include the doctor_profile.php file
            include_once('doctor_profile.php');
			} else {
            // Handle if doctor profile not found
            echo "Doctor profile not found!";
			}
			} else {
				// Handle if Doctor_id is not provided
				echo "Doctor ID not provided!";
			}
			break;

			
			case '/signup':
			
			$category_arr=$this->select('category');
			if(isset($_REQUEST['submit']))
			{
				$First_name=$_REQUEST['First_name'];
				$Last_name=$_REQUEST['Last_name'];
				$Mobile=$_REQUEST['Mobile'];
				$Username=$_REQUEST['Username'];
				$Password=md5($_REQUEST['Password']); // enc pass
				$Pet_category=$_REQUEST['Pet_category'];
				$Pet_name=$_REQUEST['Pet_name'];
				$Pet_age=$_REQUEST['Pet_age'];
			    $Pet_gender=$_REQUEST['Pet_gender'];
				// img upload
				
				$Upload_pet_profile=$_FILES['Upload_pet_profile']['name'];
				$path='img/vineeta/'.$Upload_pet_profile;
				$img_file=$_FILES['Upload_pet_profile']['tmp_name'];
				move_uploaded_file($img_file,$path);
				
				$arr_data=array("First_name"=>$First_name,'Last_name'=>$Last_name,'Mobile'=>$Mobile,"Username"=>$Username,"Password"=>$Password,"Pet_category"=>$Pet_category,"Pet_name"=>$Pet_name,"Pet_age"=>$Pet_age,"Pet_gender"=>$Pet_gender,"Upload_pet_profile"=>$Upload_pet_profile);
				
				$res=$this->insert('customer' ,$arr_data);
				if($res)
				{
					$mail = new PHPMailer;
					$mail->isSMTP();
					$mail->Host = 'smtp.gmail.com';
					$mail->Port = 587;
					$mail->SMTPSecure = 'tls';
					$mail->SMTPAuth = true;
					$mail->Username = 'vishwakarmavineeta03@gmail.com';// enter your mail
					$mail->Password = 'ihoh hhzl mlej cyje';// enter pass
					$mail->setFrom('vishwakarmavineeta03@gmail.com', 'Petsfolio');  // Enter display email & name
					$mail->addReplyTo('vishwakarmavineeta03@gmail.com', 'Petsfolio');  // enter reply to mail & name
					
					$mail->addAddress($Username); // pas to email
					$mail->Subject = 'Welcome to Petsfolio';
					$mail->msgHTML('Welcome to ' . $Username . '<br> We will contact you soon');

					if (!$mail->send()) {
					   $error = "Mailer Error: " . $mail->ErrorInfo;
						?><script>alert('<?php echo $error ?>');</script><?php
					} 
					else 
					{	
					   	echo "<script>
						alert('Register Success');
						</script>";
					}
				}
				else
				{
					echo"error";
				}
			}
			include_once('signup.php');
			break;
			
			case '/forgot_password':
			if(isset($_REQUEST['submit']))
			{
				
				$Username=$_REQUEST['Username'];
				
				$where=array("Username"=>$Username);
				
				$res=$this->select_where('customer' ,$where);
				$fetch=$res->fetch_object();
				
				
				if($fetch)
				{
					$_SESSION['user_id']=$fetch->customer_id;
					$otp=rand(000000,999999);
					$_SESSION['otp']=$otp;
					
					$mail = new PHPMailer;
					$mail->isSMTP();
					$mail->Host = 'smtp.gmail.com';
					$mail->Port = 587;
					$mail->SMTPSecure = 'tls';
					$mail->SMTPAuth = true;
					$mail->Username = 'vishwakarmavineeta03@gmail.com';// enter your mail
					$mail->Password = 'ihoh hhzl mlej cyje';// enter pass
					$mail->setFrom('vishwakarmavineeta03@gmail.com', 'Petsfolio');  // Enter display email & name
					$mail->addReplyTo('vishwakarmavineeta03@gmail.com', 'Petsfolio');  // enter reply to mail & name
					
					$mail->addAddress($Username); // pas to email
					$mail->Subject = 'Reset Password otp';
					$mail->msgHTML('Welcome to ' . $Username . '<br> Your OTP : '.$_SESSION['otp']);

					if (!$mail->send()) {
					   $error = "Mailer Error: " . $mail->ErrorInfo;
						?><script>alert('<?php echo $error ?>');</script><?php
					} 
					else 
					{	
					   	echo "<script>
						alert('OTP send Success');
						window.location='Varification_link';
						</script>";
					}
				}
				else
				{
					echo" Username doesn't Exist";
				}
			}
			include_once('forgot_password.php');
			break;
			
			case '/Varification_link':
				
					if(isset($_REQUEST['submit']))
					{
						$otp=$_REQUEST['otp'];
						if($otp==$_SESSION['otp'])
						{
								
								unset($_SESSION['otp']);
								$_SESSION['reset']="reset";
								echo "<script>
								alert('OTP match Success');
								window.location='reset_password';
								</script>";
								
						}
						else
						{
							echo "<script>
								alert('OTP Not match Success');
								</script>";
						}
					}
					include_once('Varification_link.php');
			
			break;
		
			
			case '/reset_password':
			if(isset($_REQUEST['submit']))
				{
					$Password=$_REQUEST['Password'];
					
					
					$arr_data=array("Password"=>md5($Password));
					$where=array("customer_id"=>$_SESSION['user_id']);	
						$res=$this->update('customer' ,$arr_data,$where);
						if($res)
						{
							unset($_SESSION['user_id']);
							unset($_SESSION['reset']);
							echo "<script>
								alert('Password reset success !');
								window.location='login';
							</script>";
							
						}
				}
			include_once('reset_password.php');
			break;
						
			case'/delete':
			if(isset($_REQUEST['del_Contacts_id']))
			{
				$Contacts_id=$_REQUEST['del_Contacts_id'];
				$where=array("Contacts_id"=>$Contacts_id);
				$res=$this->delete_where('contacts',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='contacts';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_appointment_id']))
			{
				$appointment_id=$_REQUEST['del_appointment_id'];
				$where=array("appointment_id"=>$appointment_id);
				$res=$this->delete_where('appointment',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='Booked_appointment';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_slot_id']))
			{
				$slot_id=$_REQUEST['del_slot_id'];
				$where=array("slot_id"=>$slot_id);
				$res=$this->delete_where('slots',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='Appointment_slots';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_Prescription_id']))
			{
				$Prescription_id=$_REQUEST['del_Prescription_id'];
				$where=array("Prescription_id"=>$Prescription_id);
				$res=$this->delete_where('prescription',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='Prescription';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_service_id']))
			{
				$service_id=$_REQUEST['del_service_id'];
				$where=array("service_id"=>$service_id);
				$res=$this->delete_where('services',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='Services';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_complain_id']))
			{
				$complain_id=$_REQUEST['del_complain_id'];
				$where=array("complain_id"=>$complain_id);
				$res=$this->delete_where('complain',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_complain';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_Product_id']))
			{
				$Product_id=$_REQUEST['del_Product_id'];
				$where=array("Product_id"=>$Product_id);
				$res=$this->delete_where('products',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='Products';
					</script>";
				}
			}
			break;
			
			case '/status':
			if(isset($_REQUEST['status_Doctor_id']))
			{
				$Doctor_id=$_REQUEST['status_Doctor_id'];
				$where=array("Doctor_id"=>$Doctor_id);
				
				$select=$this->select_where('doctor',$where);
				$fetch=$select->fetch_object();
				
				$status=$fetch->status;
				
				if($status=="Block")
				{
					$arr_data=array("status"=>"Unblock");		
					$res=$this->update('doctor',$arr_data,$where);

					if($res)
					{
						echo "<script>
							alert('Unblock success !');
							window.location='contacts';
						</script>";
					}
				}
				else
				{
					$arr_data=array("status"=>"Block");		
					$res=$this->update('doctor',$arr_data,$where);
					if($res)
					{
						echo "<script>
							alert('Block success !');
							window.location='contacts';
						</script>";
					}
				}
			}
			
			if(isset($_REQUEST['status_appointment_id']))
			{
				$appointment_id=$_REQUEST['status_appointment_id'];
				$where=array("appointment_id"=>$appointment_id);
				
				$select=$this->select_where('appointment',$where);
				$fetch=$select->fetch_object();
				
				$status=$fetch->status;
				
				if($status=="Booked")
				{
					$arr_data=array("status"=>"Unbook");		
					$res=$this->update('appointment',$arr_data,$where);
					
					if(isset($_REQUEST['status_appointment_id']))
					{
						$appointment_id=$_REQUEST['status_appointment_id'];
						$where=array("appointment_id"=>$appointment_id);
						$res=$this->delete_where('appointment',$where);
						if($res)
						{
							echo "<script>
							alert('Unbook success !');
							window.location='Booked_appointment';
							</script>";
						}
					}
					
					
				}
				else
				{
					$arr_data=array("status"=>"Booked");		
					$res=$this->update('appointment',$arr_data,$where);
					if($res)
					{
						echo "<script>
							alert('Booked success !');
							window.history.back();
						</script>";
					}
				}
			}
		
			break;
		
			default:
			include_once('pnf.php');
			break;	
		}
	}	
}
$obj=new control;	
?>