<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}	
	include_once('header.php');
	?> 	  <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Contact</h1>
                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                           Edit Contact
                        </div>
                        <div class="panel-body">
							<form action="" method="post">
							<div class="row">
								<div class="col-6 form-group">
                                    <input type="text" name="Name" value="<?php echo $fetch->Name?>" class="form-control p-4" placeholder="Your Name" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="number" name="Mobile" value="<?php echo $fetch->Mobile?>" class="form-control p-4" placeholder="Your Mobile" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="Email" name="Email" value="<?php echo $fetch->Email?>" class="form-control p-4" placeholder="Your Email" required="required">
                                </div>
								
								<div class="col-12 form-group">
									Certificate degree:</br>
                                    <input type="file"  name="Certificate_degree" class="form-control">
									<img src="assets/img/vineeta/<?php echo $fetch->Certificate_degree?>" width="100px">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="text" name="Msg" value="<?php echo $fetch->Msg?>" class="form-control p-4" placeholder="Your Massage" required="required">
                                </div>
								
								<div>
										<input class="btn btn-primary py-3 px-3" type="submit" name="update" value="submit">
			   

								</div>
							</div>

								
                        </div>
                    </div>
    

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php
   include_once('footer.php')
   ?>