<?php

	if(isset($_SESSION['Doctor_id']))
	{
		echo "<script>
			window.location='index';
		</script>";
	}
	include_once('header.php');
	?>
	
	<style>
	.field-icon {
  float: right;
  margin-left: -25px;
  margin-top: -25px;
  position: relative;
  z-index: 2;
}

.container{
  padding-top:50px;
  margin: auto;
}
	
</style>


<script>
$(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
</script>
  <!-- Contact Start -->
   	  <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Signup</h1>
                    </div>
                </div>
			<div class="row">
                <div class="col-lg-12 mb-2">
                    <div class="contact-form bg-light mb-4" style="padding: 30px;">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row">
								<div class="col-12 form-group">
                                    <input type="text" name="Name" class="form-control p-4" placeholder="Your Name" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="Mobile" name="Mobile"  class="form-control p-4" placeholder="Your Mobile" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="text" name="name_of_hospital"  class="form-control p-4" placeholder="Name Of Hospital" required="required">
                                </div>
								<div class="col-12 form-group">
									Gender:</br>
                                    Male: <input type="radio" name="gender"  value="Male">
									Female: <input type="radio" name="gender"  value="Female">
                                </div>
								
								<div class="col-12 form-group">
									Upload Profile:</br>
                                    <input type="file"  name="Upload_profile" class="form-control" required="required">
                                </div>
								
								<div class="col-12 form-group">
									License of Doctor:</br>
                                    <input type="file"  name="License_doctor" class="form-control" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="address" name="Location_hospital"  class="form-control p-4" placeholder="Your Hospital location" required="required">
                                </div>
								<div class="col-6 form-group">
								Consultancy Fees:</br>
                                    <input type="text" name="cfees" class="form-control p-4" placeholder="Your Consultancy Fees" required="required">
                                </div>
								<div class="col-6 form-group">
								Follow up Fees:</br>
                                    <input type="text" name="ffees" class="form-control p-4" placeholder="Your Follow up Fees" required="required">
                                </div>
                           
							<div class="col-6 form-group">
                                    <input type="Username" name="Username" class="form-control p-4" placeholder="Your Username" required="required">
                                </div>
								 <div class="col-6 form-group">
                                <div class="input-group">
                                    <input type="password" id="passwordInput" name="Password" class="form-control p-4" placeholder="Your Password" required="required">
                                    <div class="input-group-append">
                                        <span class="input-group-text" id="togglePassword">
                                            <i class="fa fa-eye" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>										
								
                            <div>
                                <input class="btn btn-primary py-3 px-5" type="submit" name="submit" value="Signup">
				
                            </div>
                        </form>
                    </div>
                </div>
          
            </div>
        </div>
    </div>
    <!-- Contact End -->
	<script>
    document.addEventListener('DOMContentLoaded', function() {
        var togglePassword = document.getElementById('togglePassword');
        var passwordInput = document.getElementById('passwordInput');

        togglePassword.addEventListener('click', function() {
            var type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.querySelector('i').classList.toggle('fa-eye');
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    });
</script>

<?php
   include_once('footer.php')
   ?>