<?php
	include_once('header.php');
	
	
	?>


    <!-- Page Header Start -->
    <div class="container-fluid page-header">
        <h1 class="display-3 text-uppercase text-white mb-3">My Profile</h1>
        <div class="d-inline-flex text-white">
            <h6 class="text-uppercase m-0"><a class="text-white" href="">Home</a></h6>
            <h6 class="text-body m-0 px-3">/</h6>
            <h6 class="text-uppercase text-body m-0">My Profile</h6>
        </div>
    </div>
    <!-- Page Header Start -->


    <!-- Team Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <h1 class="display-4 text-uppercase text-center mb-5">Edit Profile</h1>
            <div  style="padding: 0 30px;">
                <div class="team-item">
                    <img width="300px" src="img/vineeta/<?php echo $data->Upload_profile?>" alt="">
                    <div class=" py-4">
                        <h4 class="text-uppercase"><?php echo $data->Name?></h4>
                        <p class="m-0">User Name : <?php echo $data->Username?></p>
                        <p class="m-0">Mobile : <?php echo $data->Mobile?></p>
                        <p class="m-0">Email : <?php echo $data->Email?></p>
						<p class="m-0">Gender : <?php echo $data->gender?></p>
						<p class="m-0">Location_hospital : <?php echo $data->Location_hospital?></p>
						
						
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- Team End -->

<?php
	include_once('footer.php');
?>