<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}	
	include_once('header.php');
	?>
      
	  <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Profile</h1>
                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                          Edit Profile
                        </div>
                        <div class="panel-body">
                            
							<form method="post" enctype="multipart/form-data">
                            <div class="row">
								<div class="col-12 form-group">
                                    <input type="text" name="Name" value="<?php echo $fetch->Name?>" class="form-control p-4" placeholder="Your Name" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="Mobile" name="Mobile" value="<?php echo $fetch->Mobile?>" class="form-control p-4" placeholder="Your Mobile" required="required">
                                </div>

								<div class="col-12 form-group">
									Gender:</br>
									<?php
									$gen=$fetch->gender;
									if($gen=="Male")
									{
									?>
										Male: <input type="radio" name="gender"  value="Male" checked>
										Female: <input type="radio" name="gender"  value="Female">
									<?php
									}
									else
									{
									?>
										Male: <input type="radio" name="gender"  value="Male" >
										Female: <input type="radio" name="gender"  value="Female" checked>
									<?php
									}
									?>	
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="text" name="Location_hospital"  value="<?php echo $fetch->Location_hospital?>" class="form-control p-4" placeholder="Your Location hospital" required="required">
                                </div>
								
								<div class="col-12 form-group">
									Upload Profile:</br>
                                    <input type="file"  name="Upload_profile" class="form-control">
									<img src="assets/img/vineeta/<?php echo $fetch->Upload_profile?>" width="100px">
                                </div>
																
								<div class="col-6 form-group">
								Consultancy Fees:</br>
                                    <input type="text" name="cfees"  value="<?php echo $fetch->cfees?>" class="form-control p-4" placeholder="Your Consultancy Fees" required="required">
                                </div>
								
								<div class="col-6 form-group">
								Follow up Fees
                                    <input type="text" name="ffees"  value="<?php echo $fetch->ffees?>" class="form-control p-4" placeholder="Your Follow up Fees" required="required">
                                </div>
								                           
							<div class="col-6 form-group">
                                    <input type="Username" name="Username" value="<?php echo $fetch->Username?>" class="form-control p-4" placeholder="Your Username" required="required">
                                </div>
                                
                            
                            <div>
                                <input class="btn btn-primary py-3 px-5" type="submit" name="update" value="Save">

                            </div>
                        </div>
                            </div>
    

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php
   include_once('footer.php')
   ?>