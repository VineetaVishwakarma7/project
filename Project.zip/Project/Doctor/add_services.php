<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}	
   include_once('header.php')
   ?>      
	  <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Add services</h1>
                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                           Add services
                        </div>
                        <div class="panel-body">
							<form action="" method="post">
							<div class="row">
                            <div class="col-12 form-group">
                                    <input type="hidden" name="Doctor_id" value="<?php echo $_SESSION['Doctor_id']?>">
                                </div>                                
								<div class="col-12 form-group">
                                    <input type="text" name="service_name" class="form-control p-4" placeholder="Service Name" required="required">
                                </div>
								<div class="col-12 form-group">
                                    <input type="text" name="detail" class="form-control p-4" placeholder="Detail" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="number" name="price"  class="form-control p-4" placeholder="Price" required="required">
                                </div>
								<div>
                                <input class="btn btn-primary py-3 px-5" type="submit" name="submit" value="submit">
								</div>
							</div>

								
                        </div>
                    </div>
    

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php
   include_once('footer.php')
   ?>