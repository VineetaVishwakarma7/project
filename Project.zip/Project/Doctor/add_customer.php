﻿<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}	
   include_once('header.php')
   ?>      
	  <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Add customer</h1>
                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                           Add customer
                        </div>
                        <div class="panel-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row">
								<div class="col-12 form-group">
                                    <input type="text" name="First_name" class="form-control p-4" placeholder="Your First Name" required="required">
                                </div>
                                <div class="col-12 form-group">
                                    <input type="text" name="Last_name" class="form-control p-4" placeholder="Your Last Name" required="required">
                                </div>
								
								<div class="col-6 form-group">
                                    <input type="text" name="Mobile"  class="form-control p-4" placeholder="Your Mobile" required="required">
                                </div>
								<div class="col-6 form-group">
                                    <input type="Email" name="Username"  class="form-control p-4" placeholder="Your Username" required="required">
                                </div>

                                <div class="col-6 form-group">
                                    <input type="password" name="Password"  class="form-control p-4" placeholder="Your Password" required="required">
                                </div>

                                <div class="col-12 form-group">
									Select Pet Category:</br>
                                   <select name="Pet_category" class="form-control">
                                   <option value="">Not Selected</option>
										<?php
										foreach($category_arr as $c)
										{
										?>
										<option value="<?php echo $c->cate_name;?>"> <?php echo $c->cate_name;?> </option>
										<?php
										}
										?>
								   </select>
                                </div>
                               	
								
								
								<div class="col-6 form-group">
                                    <input type="text" name="Pet_name"  class="form-control p-4" placeholder="Your Pet name" required="required">
                                </div>
								

                                <div class="col-6 form-group">
                                    <input type="number"  name="Pet_age" class="form-control p-4" placeholder="Your Pet age" required="required">
                                </div>

                                
                                <div class="col-12 form-group">
                                    Pet gender:</br>
                                    Male: <input type="radio" name="Pet_gender" value="Male">
                                    Female: <input type="radio" name="Pet_gender" value="Female">
                                </div>



                                							
								<div class="col-12 form-group">
									Upload Pet Profile:</br>
                                    <input type="file"  name="Upload_pet_profile" class="form-control" required="required">
                                </div>

                            
                            <div>
                                <input class="btn btn-primary py-3 px-5" type="submit" name="submit" value="submit">

                            </div>
                        </div>
                            </div>
    

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php
   include_once('footer.php')
   ?>