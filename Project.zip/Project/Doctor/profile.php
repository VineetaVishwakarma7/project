<?php
if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
   include_once('header.php')
   ?>
<div id="page-wrapper">
    <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Profile</h1>
                    </div>
                </div>    
				
            <div  style="padding: 12 400px;">
                <div class="team-item">
                    
                    <img width="300px" src="assets/img/vineeta/<?php echo $data->Upload_profile?>" alt="">
                    <div class=" py-4">
                        <h4 class="text-uppercase"><?php echo $data->Name?></h4>
                        <p class="m-0">User Name : <?php echo $data->Username?></p>
                        <p class="m-0">Mobile : <?php echo $data->Mobile?></p>
						<p class="m-0">Name of hospital : <?php echo $data->name_of_hospital?></p>
						<p class="m-0">Gender : <?php echo $data->gender?></p>
						<p class="m-0">Location_hospital : <?php echo $data->Location_hospital?></p>
						<p class="m-0">Consultancy Fees : <?php echo $data->cfees?></p>
						<p class="m-0">Follow up Fees : <?php echo $data->ffees?></p>
						
						<a href="edit_doctor?edit_Doctor_id=<?php echo $data->Doctor_id ;?>" class="btn btn-primary">Edit</a>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
                        
    