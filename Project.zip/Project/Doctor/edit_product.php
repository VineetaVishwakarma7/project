<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}	
	include_once('header.php');
	?>    
	  <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit products</h1>
                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                           Edit products
                        </div>
                                                        
                        <div class="panel-body">
                            <form method="post" >
                            <div class="row">
							
							<div class="col-12 form-group">
									Upload Product:</br>
                                    <input type="file"  name="p_img" class="form-control">
									<img src="assets/img/vineeta/<?php echo $fetch->p_img?>" width="100px">
                                </div>
								<div class="col-12 form-group">
                                    <input type="text" name="Product_name" value="<?php echo $fetch->Product_name?>" class="form-control p-4" placeholder="Product Name" required="required">
                                </div>
                                <div class="col-12 form-group">
									Select Product Category:</br>
                                   <select name="Product_category" class="form-control">
                                    <option value="">Not Selected</option>
										<?php
										foreach($category_arr as $c)
										{
											if($fetch->Product_category==$c->cate_name)
											{
										?>
										<option value="<?php echo $c->cate_name;?>" selected> <?php echo $c->cate_name;?> </option>
										<?php
											}
											else
											{
										?>
											<option value="<?php echo $c->cate_name;?>"> <?php echo $c->cate_name;?></option>
										<?php
										
											}
										}
										?>
								   </select>
                                </div>
								<div class="col-6 form-group">
                                    <input type="number" name="Price" value="<?php echo $fetch->Price?>" class="form-control p-4" placeholder="Price" required="required">
                                </div>
								<div>
                                <input class="btn btn-primary py-3 px-5" type="submit" name="update" value="Save">
								</div>
                        </div>
		
				</div>
               </div>
           </div>
    

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php
   include_once('footer.php')
   ?>