﻿	<?php
    if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
   include_once('header.php')
   ?>
   
    <?php
   if (isset($_SESSION['Doctor_id'])) {
    $Doctor_id=$_SESSION['Doctor_id'];
    $obj = new model;
    $appoi_arr = $obj->select_where('appointment', array("Doctor_id" => $Doctor_id));
} else {
    echo "Doctor ID not provided!";
}

   ?>

		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Appointments</h1>
                        
                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Appoinments
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>slot_id</th>
                                            <th>Date</th>
                                            <th>Time</th>
                                            <th>customer_id</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php
										if(!empty($appoi_arr))
										{
											foreach($appoi_arr as $c)
											{
										?>
										<tr>
                                            <td><?php echo $c['slot_id']?></td>
                                            <td><?php echo $c['Date']?></td>
											<td><?php echo $c['Time']?></td>
                                            <td><?php echo $c['customer_id']?></td>
                                        </tr>
										<?php
										}
										}
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>