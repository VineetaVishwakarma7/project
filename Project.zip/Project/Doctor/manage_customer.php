﻿	<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
   include_once('header.php')
   ?>
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage customer</h1>
                        
                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-12">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manage customer
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>First name</th>
                                            <th>Last name</th>
                                            <th>Mobile</th>
											<th>Username</th>
											<th>Pet category</th>
											<th>Pet name</th>
											<th>Pet age</th>
                                            <th>Pet gender</th>
											<th>Profile</th>
                                            <th align="center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
										if(!empty($cust_arr))
										{
											foreach($cust_arr as $c)
											{
										?>
										<tr>
                                            <td><?php echo$c->First_name?></td>
                                            <td><?php echo$c->Last_name?></td>
                                            <td><?php echo$c->Mobile?></td>
											<td><?php echo$c->Username?></td>
                                            <td><?php echo$c->Pet_category?></td>
											<td><?php echo$c->Pet_name?></td>
											<td><?php echo$c->Pet_age?></td>
                                            <td><?php echo$c->Pet_gender?></td>
                                            <td><img src="assets/img/vineeta/<?php echo$c->Upload_pet_profile?>"width="50px"></td>
										

                                        <td align="center">
										<a href="delete?del_customer_id=<?php echo $c->customer_id;?>" class="btn btn-danger">Delete</a>
										<a href="status?status_customer_id=<?php echo $c->customer_id;?>" class="btn btn-primary"><?php echo $c->status;?></a>
										</td>
                                        </tr>
										<?php
											}
										}
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>