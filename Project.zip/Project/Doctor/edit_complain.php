<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}	
	include_once('header.php');
	?>       
	  <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Complain</h1>
                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                           Edit Complain
                        </div>
                        <div class="panel-body">
							<form action="" method="post">
							<div class="row">
								<div class="col-6 form-group">
                                    <input type="text" name="Note" value="<?php echo $fetch->Note?>" class="form-control p-4" placeholder="Your Note" required="required">
                                </div>
								<div class="col-6 form-group">
                                    <input type="text" name="Rate" value="<?php echo $fetch->Rate?>" class="form-control p-4" placeholder="Your Rate" required="required">
                                </div>
								
								<div>
										<input class="btn btn-primary py-3 px-3" type="submit" name="update" value="submit">
			   

								</div>
							</div>

								
                        </div>
                    </div>
    

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php
   include_once('footer.php')
   ?>