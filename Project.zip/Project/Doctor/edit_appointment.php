<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}	
	include_once('header.php');
	?>    
	  <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Appointment </h1>
                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                           Edit Appointment 
                        </div>
                                                        
                        <div class="panel-body">
                            <form method="post" >
                            <div class="row">
								
                                
								<div class="col-12 form-group">
                                    <input type="Date" name="Date" value="<?php echo $fetch->Date?>" class="form-control p-4" placeholder="Your Date" required="required">
                                </div>
								
								<div class="col-12 form-group">
									Select Customer:</br>
                                   <select name="customer_id" class="form-control">
                                    <option value="">Not Selected</option>
										<?php
										foreach($customer_arr as $c)
										{
											if($fetch->customer_id==$c->customer_id)
											{
										?>
										<option value="<?php echo $c->customer_id;?>" selected> <?php echo $c->customer_id;?> </option>
										<?php
											}
											else
											{
										?>
											<option value="<?php echo $c->customer_id;?>"> <?php echo $c->customer_id;?></option>
										<?php
										
											}
										}
										?>
								   </select>
                                </div>
								
								
								<div class="col-6 form-group">
                                    <input type="Time" name="Time" value="<?php echo $fetch->Time?>" class="form-control p-4" placeholder="Your Time" required="required">
                                </div>
								<div>
                                <input class="btn btn-primary py-3 px-5" type="submit" name="update" value="Save">
								</div>
                        </div>
		
				</div>
               </div>
           </div>
    

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php
   include_once('footer.php')
   ?> 