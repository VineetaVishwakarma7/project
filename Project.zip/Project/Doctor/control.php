<?php

include_once('../Admin/model.php');

class control extends model
{
	// __construct magic function auto call after taken object
	function __construct()
		{
		require 'phpmailer/PHPMailerAutoload.php';

		model::__construct();
		// url 
		session_start();
		$url=$_SERVER['PATH_INFO'];	
		
		switch($url)
		{
			case '/signup':
			if(isset($_REQUEST['submit']))
			{
				$Name=$_REQUEST['Name'];
				$Mobile=$_REQUEST['Mobile'];
				$gender=$_REQUEST['gender'];
			
				//img upload
				$Upload_profile=$_FILES['Upload_profile']['name'];
				
				$path='assets/img/vineeta/'.$Upload_profile;
				$img_file=$_FILES['Upload_profile']['tmp_name'];
				move_uploaded_file($img_file,$path);
				
				
				//img upload
				$License_doctor=$_FILES['License_doctor']['name'];
				
				$path='assets/img/vineeta/'.$License_doctor;
				$img_file=$_FILES['License_doctor']['tmp_name'];
				move_uploaded_file($img_file,$path);
				
				$Location_hospital=$_REQUEST['Location_hospital'];
				$cfees=$_REQUEST['cfees'];
				$ffees=$_REQUEST['ffees'];
				$Username=$_REQUEST['Username'];
				$Password=md5($_REQUEST['Password']);
				
				$arr_data=array("Name"=>$Name,"Mobile"=>$Mobile,"gender"=>$gender,"Upload_profile"=>$Upload_profile,"License_doctor"=>$License_doctor,"cfees"=>$cfees,"ffees"=>$ffees,"Location_hospital"=>$Location_hospital,"Username"=>$Username,"Password"=>$Password);
				
				$res=$this->insert('doctor',$arr_data);
				if($res)
				{
					echo "<script>
						alert('inquiry Subbmited success !');
					</script>";
				}
				else
				{
					echo "error";
				}	
				
			}
			include_once('signup.php');
			break;
			
			case '/index':
				if(isset($_REQUEST['doctorlogin']))
				{
					$Username=$_REQUEST['Username'];
					$passe=$_REQUEST['Password'];
					$Password=md5($_REQUEST['Password']);  // enc Password
					
					$where=array("Username"=>$Username,"Password"=>$Password);
					
					$res=$this->select_where('doctor',$where);
					$chk=$res->num_rows; // check fetch data by rows
					if($chk==1)
					{
						// session create
						$fetch=$res->fetch_object();

						if($fetch->status=="Unblock")
						{	
						$_SESSION['Doctor_id']=$fetch->Doctor_id  ;
						$_SESSION['Username']=$fetch->Username;
						$_SESSION['Name']=$fetch->Name;
						// cookie create 		
						if(isset($_REQUEST['rem']))
						{
							setcookie('emailcookie',$Username,time()+30);
							setcookie('passcookie',$passe,time()+30);
						}
						echo "<script>
							alert('Login success !');
							window.location='Dashboard';
						</script>";
						}
						else
						{
						echo "<script>
							alert('Login Failed due to account Blocked !');
							window.location='index';
						</script>";
						}
					}
					else
					{
						echo "<script>
							alert('Login Failed due to Wrong Creadential! ');
						</script>";
					}	
					
					}
			include_once('index.php');
			break;

			case '/profile':
				if(isset($_SESSION['Doctor_id']))
					{
						$arr=array('Doctor_id'=>$_SESSION['Doctor_id']);
						$res=$this->select_where('doctor',$arr);
						$data=$res->fetch_object();
						include_once('profile.php');
					}
					else
					{
						echo "<script>
							window.location='Dashboard';
						<	/script>";
					}
			break;
				
			case '/edit_doctor':
			if(isset($_REQUEST['edit_Doctor_id']))
			{
				$Doctor_id=$_REQUEST['edit_Doctor_id'];
				$where=array("Doctor_id"=>$Doctor_id);
				
				$res=$this->select_where('doctor',$where);
				$fetch=$res->fetch_object();
				
				// if user update img then delete old imag
				$oldimg=$fetch->Upload_profile;
												
				if(isset($_REQUEST['update']))
				{
					
				$Name=$_REQUEST['Name'];
				$Mobile=$_REQUEST['Mobile'];
				$gender=$_REQUEST['gender'];
				$Location_hospital=$_REQUEST['Location_hospital'];
				$cfees=$_REQUEST['cfees'];
				$ffees=$_REQUEST['ffees'];
				$Username=$_REQUEST['Username'];
			
				//img upload
				if($_FILES['Upload_profile']['size']>0)
				{
				$Upload_profile=$_FILES['Upload_profile']['name'];
				$path='assets/img/vineeta/'.$Upload_profile;
				$img_file=$_FILES['Upload_profile']['tmp_name'];
				move_uploaded_file($img_file,$path);
							
				$arr_data=array("Name"=>$Name,"Mobile"=>$Mobile,"gender"=>$gender,"Upload_profile"=>$Upload_profile,"Location_hospital"=>$Location_hospital,"cfees"=>$cfees,"ffees"=>$ffees,"Username"=>$Username);
				
				$res=$this->update('doctor',$arr_data,$where);
					if($res)
						{
							unlink('assets/img/vineeta/'.$oldimg); // 	delete old img
							echo "<script>
								alert('update success !');
								window.location='profile';
							</script>";
						}
				}
					else
					{
						$arr_data=array("Name"=>$Name,"Mobile"=>$Mobile,"gender"=>$gender,"Location_hospital"=>$Location_hospital,"Username"=>$Username);
						
						$res=$this->update('doctor',$arr_data,$where);
						if($res)
						{
							echo "<script>
								alert('update success !');
								window.location='profile';
							</script>";
						}
					}		
				}
			}
			include_once('edit_doctor.php');
			break;					
			
			case '/doctorlogout':
			unset($_SESSION['Doctor_id']);
			unset($_SESSION['Username']);
			unset($_SESSION['Name']);
			echo "<script>
					alert('Logout success !');
					window.location='index';
				  </script>";
			break;
	

			case '/Dashboard':
			include_once('Dashboard.php');
			break;

			case '/add_customer':
			$category_arr=$this->select('category');
			if(isset($_REQUEST['submit']))
			{
				$First_name=$_REQUEST['First_name'];
				$Last_name=$_REQUEST['Last_name'];
				$Mobile=$_REQUEST['Mobile'];
				$Username=$_REQUEST['Username'];
				$Password=md5($_REQUEST['Password']);
				$Pet_category=$_REQUEST['Pet_category'];
				$Pet_name=$_REQUEST['Pet_name'];
				$Pet_age=$_REQUEST['Pet_age'];
				$Pet_gender=$_REQUEST['Pet_gender'];
					
				//img upload
				$Upload_pet_profile=$_FILES['Upload_pet_profile']['name'];
					
				$path='assets/img/vineeta/'.$Upload_pet_profile;
				$img_file=$_FILES['Upload_pet_profile']['tmp_name'];
				move_uploaded_file($img_file,$path);
						
				$arr_data=array("First_name"=>$First_name,"Last_name"=>$Last_name,"Mobile"=>$Mobile,"Username"=>$Username,"Password"=>$Password,"Pet_category"=>$Pet_category,"Pet_name"=>$Pet_name,"Pet_age"=>$Pet_age,"Pet_gender"=>$Pet_gender,"Upload_pet_profile"=>$Upload_pet_profile);
					
				$res=$this->insert('customer',$arr_data);
					if($res)
					{
						echo "<script>
							alert('inquiry Subbmited success !');
						</script>";
					}
					else
					{
						echo "error";
					}	
					
			}
			include_once('add_customer.php');
			break;
			
			case '/edit_user':
			$category_arr=$this->select('category');
			if(isset($_REQUEST['edit_customer_id']))
			{
				$customer_id=$_REQUEST['edit_customer_id'];
				$where=array("customer_id"=>$customer_id);
				
				$res=$this->select_where('customer',$where);
				$fetch=$res->fetch_object();
				// if user update img then delete old image
				$oldimg=$fetch->Upload_pet_profile;
				
				if(isset($_REQUEST['update']))
				{
					$First_name=$_REQUEST['First_name'];
					$Last_name=$_REQUEST['Last_name'];
					$Mobile=$_REQUEST['Mobile'];
					$Username=$_REQUEST['Username'];
					$Pet_category=$_REQUEST['Pet_category'];
					$Pet_name=$_REQUEST['Pet_name'];
					$Pet_age=$_REQUEST['Pet_age'];
					$Pet_gender=$_REQUEST['Pet_gender'];
					
					//img upload
					if($_FILES['Upload_pet_profile']['size']>0)
					{
						$Upload_pet_profile=$_FILES['Upload_pet_profile']['name'];
						$path='assets/img/vineeta/'.$Upload_pet_profile;
						$img_file=$_FILES['Upload_pet_profile']['tmp_name'];
						move_uploaded_file($img_file,$path);
					
						$arr_data=array("First_name"=>$First_name,'Last_name'=>$Last_name,'Mobile'=>$Mobile,"Username"=>$Username,"Pet_category"=>$Pet_category,"Pet_name"=>$Pet_name,"Pet_age"=>$Pet_age,"Pet_gender"=>$Pet_gender,"Upload_pet_profile"=>$Upload_pet_profile);
						
						$res=$this->update('customer',$arr_data,$where);
						if($res)
						{
							unlink('assets/img/vineeta/'.$oldimg); // 	delete old img
							echo "<script>
								alert('Update success !');
								window.location='manage_customer';
							</script>";
						}
					}
					else
					{
						$arr_data=array("First_name"=>$First_name,'Last_name'=>$Last_name,'Mobile'=>$Mobile,"Username"=>$Username,"Pet_category"=>$Pet_category,"Pet_name"=>$Pet_name,"Pet_age"=>$Pet_age,"Pet_gender"=>$Pet_gender);
						
						$res=$this->update('customer' ,$arr_data,$where);
						if($res)
						{
							echo "<script>
								alert('Update success !');
								window.location='manage_customer';
							</script>";
						}
					}
				}
			}
			include_once('edit_user.php');
			break;
				
						
			case '/manage_customer':
			$cust_arr=$this->select('customer');
			include_once('manage_customer.php');
			break;

			case '/edit_appointment':
			$customer_arr=$this->select('customer');
			if(isset($_REQUEST['edit_appointment_id']))
			{
				$appointment_id=$_REQUEST['edit_appointment_id'];
				$where=array("appointment_id"=>$appointment_id);
				
				$res=$this->select_where('appointment',$where);
				$fetch=$res->fetch_object();
													
					if(isset($_REQUEST['update']))
					{
					$Date=$_REQUEST['Date'];
					$customer_id=$_REQUEST['customer_id'];
					$Time=$_REQUEST['Time'];
					
					$arr_data=array("Date"=>$Date,"customer_id"=>$customer_id,"Time"=>$Time);
					
					$res=$this->update('appointment',$arr_data,$where);
						if($res)
							{
								
								echo "<script>
									alert('Upadte success !');
									window.location='manage_appointments';
								</script>";
							}
					}
			}	
			include_once('edit_appointment.php');
			break;
						
			case '/Appoinments':
			$appoi_arr=$this->select('appointment');
			include_once('manage_appointments.php');
			break;

			case '/edit_slot':
			$doctor_arr=$this->select('doctor');
			if(isset($_REQUEST['edit_slot_id']))
			{
					$slot_id =$_REQUEST['edit_slot_id'];
					$where=array("slot_id "=>$slot_id );
					
					$res=$this->select_where('slots',$where);
					$fetch=$res->fetch_object();
													
					if(isset($_REQUEST['update']))
					{					
					$Doctor_id =$_REQUEST['Doctor_id'];
					$Time=$_REQUEST['Time'];
					
					$arr_data=array("Doctor_id "=>$Doctor_id,"Time"=>$Time);
					
					$res=$this->update('slots',$arr_data,$where);
						if($res)
							{
								
								echo "<script>
									alert('Upadte success !');
									window.location='manage_appointment_slots';
								</script>";
							}
					}
			}	
			include_once('edit_slot.php');
			break;
			
			case '/manage_appointment_slots':
			$slot_arr=$this->select('slots');
			include_once('manage_appointment_slots.php');
			break;
			
			case '/add_slots':
			$doctor_arr=$this->select('doctor');
			if(isset($_REQUEST['submit']))
			{
				$Doctor_id=$_REQUEST['Doctor_id'];
				$Time=$_REQUEST['Time'];
				
				$arr_data=array("Doctor_id"=>$Doctor_id,"Time"=>$Time);
					
				$res=$this->insert('slots',$arr_data);
				if($res)
				
				{
					echo "<script>
						alert('inquiry Subbmited success !');
					</script>";
				}
				else
				{
					echo "error";
				}	
				
			}
			include_once('add_slots.php');
			break;
			
			case '/manage_services':
			$serv_arr=$this->select('services');
			include_once('manage_services.php');
			break;
			
			case '/edit_service':
			if(isset($_REQUEST['edit_service_id']))
			{
				$service_id=$_REQUEST['edit_service_id'];
				$where=array("service_id"=>$service_id);
				
				$res=$this->select_where('services',$where);
				$fetch=$res->fetch_object();
												
				if(isset($_REQUEST['update']))
				{
				$service_name=$_REQUEST['service_name'];
				$price=$_REQUEST['price'];
				
				$arr_data=array("service_name"=>$service_name,"price"=>$price);
				
				$res=$this->update('services',$arr_data,$where);
					if($res)
						{
							
							echo "<script>
								alert('Upadte success !');
								window.location='manage_services';
							</script>";
						}
				}
			}	
			include_once('edit_service.php');
			break;	
			
			case '/add_services':
			$doctor_arr=$this->select('doctor');
			if(isset($_REQUEST['submit']))
			{
				$Doctor_id=$_REQUEST['Doctor_id'];
				$service_name=$_REQUEST['service_name'];
				$price=$_REQUEST['price'];
				$detail=$_REQUEST['detail'];
				
				$arr_data=array("Doctor_id"=>$Doctor_id,"service_name"=>$service_name,"price"=>$price,"detail"=>$detail);
				
				$res=$this->insert('services',$arr_data);
				if($res)
				{
					echo "<script>
						alert('inquiry Subbmited success !');
					</script>";
				}
				else
				{
					echo "error";
				}	
				
			}
			include_once('add_services.php');
			break;
			
			case '/manage_contact':
			$cont_arr=$this->select('contacts');
			include_once('manage_contact.php');
			break;

			case '/edit_contact':
			if(isset($_REQUEST['edit_Contacts_id']))
			{
				$Contacts_id=$_REQUEST['edit_Contacts_id'];
				$where=array("Contacts_id"=>$Contacts_id);
				
				$res=$this->select_where('contacts',$where);
				$fetch=$res->fetch_object();
				
				// if user update img then delete old imag
				$oldimg=$fetch->Certificate_degree;
												
				if(isset($_REQUEST['update']))
				{
				$Name=$_REQUEST['Name'];
				$Mobile=$_REQUEST['Mobile'];
				$Email=$_REQUEST['Email'];
				$Msg=$_REQUEST['Msg'];
				
				//img upload
				if($_FILES['Certificate_degree']['size']>0)
				{
				$Certificate_degree=$_FILES['Certificate_degree']['name'];
				$path='assets/img/vineeta/'.$Certificate_degree;
				$img_file=$_FILES['Certificate_degree']['tmp_name'];
				move_uploaded_file($img_file,$path);
							
				$arr_data=array("Name"=>$Name,"Mobile"=>$Mobile,"Email"=>$Email,"gender"=>$gender,"Certificate_degree"=>$Certificate_degree,"Msg"=>$Msg);
				
				$res=$this->update('contacts',$arr_data,$where);
					if($res)
						{
							unlink('assets/img/vineeta/'.$oldimg); // 	delete old img
							echo "<script>
								alert('Upadte success !');
								window.location='manage_contact';
							</script>";
						}
				}
					else
					{
						$arr_data=array("Name"=>$Name,"Mobile"=>$Mobile,"Email"=>$Email,"Msg"=>$Msg);
						
						$res=$this->update('contacts',$arr_data,$where);
						if($res)
						{
							echo "<script>
								alert('Upadte success !');
								window.location='manage_contact';
							</script>";
						}
					}		
				}
			}
			include_once('edit_contact.php');
			break;			
			
			case '/add_products':
			
			$category_arr=$this->select('category');
			if(isset($_REQUEST['submit']))
			{
				$Doctor_id=$_REQUEST['Doctor_id'];
				$p_img=$_REQUEST['p_img'];
				$Product_name=$_REQUEST['Product_name'];
				$Product_category=$_REQUEST['Product_category'];
				$Price=$_REQUEST['Price'];
				
				$arr_data=array("Doctor_id"=>$Doctor_id,"p_img"=>$p_img,"Product_name"=>$Product_name,"Product_category"=>$Product_category,"Price"=>$Price);
				
				$res=$this->insert('product',$arr_data);
				if($res)
				
				{
					echo "<script>
						alert('inquiry Subbmited success !');
					</script>";
				}
				else
				{
					echo "error";
				}	
				
			}
			include_once('add_products.php');
			break;
			
			case '/edit_product':
			$category_arr=$this->select('category');
			if(isset($_REQUEST['edit_Product_id']))
			{
				$Product_id=$_REQUEST['edit_Product_id'];
				$where=array("Product_id"=>$Product_id);
				
				$res=$this->select_where('product',$where);
				$fetch=$res->fetch_object();

				// if user update img then delete old image
				$oldimg=$fetch->p_img;
																
				if(isset($_REQUEST['update']))
				{
					$Product_name=$_REQUEST['Product_name'];
					$Product_category=$_REQUEST['Product_category'];
					$Price=$_REQUEST['Price'];
				
					//img upload
					if($_FILES['p_img']['size']>0)
					{
						$p_img=$_FILES['p_img']['name'];
						$path='assets/img/vineeta/'.$p_img;
						$img_file=$_FILES['p_img']['tmp_name'];
						move_uploaded_file($img_file,$path);
				
						$arr_data=array("p_img"=>$p_img,"Product_name"=>$Product_name,"Product_category"=>$Product_category,"Price"=>$Price);
					
						$res=$this->update('product',$arr_data,$where);
						if($res)
						{
							unlink('assets/img/vineeta/'.$oldimg); // 	delete old img
							echo "<script>
								alert('Upadte success !');
								window.location='manage_products';
							</script>";
						}
					}
					else
					{
						$arr_data=array("Product_name"=>$Product_name,"Product_category"=>$Product_category,"Price"=>$Price);
				
						$res=$this->update('product',$arr_data,$where);
						if($res)
						{
							echo "<script>
								alert('Upadte success !');
								window.location='manage_products';
							</script>";
						}
					}		
				}
			}
			include_once('edit_product.php');
			break;	
			
			case '/manage_products':
			$prod_arr=$this->select('product');
			include_once('manage_products.php');
			break;

			case '/edit_prescription':
			$customer_arr=$this->select('customer');
			if(isset($_REQUEST['edit_Prescription_id']))
			{
					$Prescription_id =$_REQUEST['edit_Prescription_id'];
					$where=array("Prescription_id "=>$Prescription_id );
						
					$res=$this->select_where('prescription',$where);
					$fetch=$res->fetch_object();
														
						if(isset($_REQUEST['update']))
						{					
						$customer_id =$_REQUEST['customer_id'];
						$Old_prescription=$_REQUEST['Old_prescription'];
												
						$arr_data=array("customer_id "=>$customer_id,"Old_prescription"=>$Old_prescription);
						
						$res=$this->update('prescription',$arr_data,$where);
							if($res)
								{
									
									echo "<script>
										alert('Upadte success !');
										window.location='manage_prescription';
									</script>";
								}
						}
			}	
			include_once('edit_prescription.php');
			break;

			case '/add_prescription':
			
			$customer_arr=$this->select('customer');
			if(isset($_REQUEST['submit']))
			{
				$Doctor_id=$_REQUEST['Doctor_id'];
				$Old_prescription=$_REQUEST['Old_prescription'];
				$customer_id=$_REQUEST['customer_id'];
				
				$arr_data=array("Doctor_id"=>$Doctor_id,"Old_prescription"=>$Old_prescription,"customer_id"=>$customer_id);
				
				$res=$this->insert('prescription',$arr_data);
				if($res)
				
				{
					echo "<script>
						alert('inquiry Subbmited success !');
					</script>";
				}
				else
				{
					echo "error";
				}	
				
			}
			include_once('add_prescription.php');
			break;
			
			case '/manage_prescription':
			$pres_arr=$this->select('prescription');
			include_once('manage_prescription.php');
			break;
			
			case '/edit_complain':
			if(isset($_REQUEST['edit_complain_id']))
			{
				$complain_id=$_REQUEST['edit_complain_id'];
				$where=array("complain_id"=>$complain_id);
				
				$res=$this->select_where('complain',$where);
				$fetch=$res->fetch_object();
				
				if(isset($_REQUEST['update']))
				{
					$Note=$_REQUEST['Note'];
					$Rate=$_REQUEST['Rate'];
					
					$arr_data=array("Note"=>$Note,'Rate'=>$Rate);
						
						$res=$this->update('complain',$arr_data,$where);
						if($res)
						{
							echo "<script>
								alert('Update success !');
								window.location='manage_complain';
							</script>";
						}
						
				}
			}
			include_once('edit_complain.php');
			break;

			case '/Complain':
			$comp_arr=$this->select('complain');
			include_once('manage_complain.php');
			break;

			case '/forgot_password':
				if(isset($_REQUEST['submit']))
				{
					
					$Username=$_REQUEST['Username'];
					
					$where=array("Username"=>$Username);
					
					$res=$this->select_where('doctor' ,$where);
					$fetch=$res->fetch_object();
					
					
					if($fetch)
					{
						$_SESSION['user_id']=$fetch->Doctor_id;
						$otp=rand(000000,999999);
						$_SESSION['otp']=$otp;
						
						$mail = new PHPMailer;
						$mail->isSMTP();
						$mail->Host = 'smtp.gmail.com';
						$mail->Port = 587;
						$mail->SMTPSecure = 'tls';
						$mail->SMTPAuth = true;
						$mail->Username = 'vishwakarmavineeta03@gmail.com';// enter your mail
						$mail->Password = 'ihoh hhzl mlej cyje';// enter pass
						$mail->setFrom('vishwakarmavineeta03@gmail.com', 'Petsfolio');  // Enter display email & name
						$mail->addReplyTo('vishwakarmavineeta03@gmail.com', 'Petsfolio');  // enter reply to mail & name
						
						$mail->addAddress($Username); // pas to email
						$mail->Subject = 'Reset Password otp';
						$mail->msgHTML('Welcome to ' . $Username . '<br> Your OTP : '.$_SESSION['otp']);
	
						if (!$mail->send()) {
						   $error = "Mailer Error: " . $mail->ErrorInfo;
							?><script>alert('<?php echo $error ?>');</script><?php
						} 
						else 
						{	
							   echo "<script>
							alert('OTP send Success');
							window.location='Varification_link';
							</script>";
						}
					}
					else
					{
						echo" Username doesn't Exist";
					}
				}
				include_once('forgot_password.php');
				break;
				
				case '/Varification_link':
					
						if(isset($_REQUEST['submit']))
						{
							$otp=$_REQUEST['otp'];
							if($otp==$_SESSION['otp'])
							{
									
									unset($_SESSION['otp']);
									$_SESSION['reset']="reset";
									echo "<script>
									alert('OTP match Success');
									window.location='reset_password';
									</script>";
									
							}
							else
							{
								echo "<script>
									alert('OTP Not match Success');
									</script>";
							}
						}
						include_once('Varification_link.php');
				
				break;
			
				
				case '/reset_password':
				if(isset($_REQUEST['submit']))
					{
						$Password=$_REQUEST['Password'];
						
						
						$arr_data=array("Password"=>md5($Password));
						$where=array("Doctor_id"=>$_SESSION['user_id']);	
							$res=$this->update('doctor' ,$arr_data,$where);
							if($res)
							{
								unset($_SESSION['user_id']);
								unset($_SESSION['reset']);
								echo "<script>
									alert('Password reset success !');
									window.location='index';
								</script>";
								
							}
					}
				include_once('reset_password.php');
				break;
			
			case'/delete':
			
			if(isset($_REQUEST['del_Prescription_id']))
			{
				$Prescription_id=$_REQUEST['del_Prescription_id'];
				$where=array("Prescription_id"=>$Prescription_id);
				$res=$this->delete_where('prescription',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_prescription';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_customer_id']))
			{
				$customer_id=$_REQUEST['del_customer_id'];
				$where=array("customer_id"=>$customer_id);
				
				$select=$this->select_where('customer',$where);
				$fetch=$select->fetch_object();
				
				$oldUpload_pet_profile=$fetch->Upload_pet_profile;
				
				$res=$this->delete_where('customer',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_customer';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_Contacts_id']))
			{
				$Contacts_id=$_REQUEST['del_Contacts_id'];
				$where=array("Contacts_id"=>$Contacts_id);
				
				$select=$this->select_where('contacts',$where);
				$fetch=$select->fetch_object();
				
				$oldCertificate_degree=$fetch->Certificate_degree;
				
				$res=$this->delete_where('contacts',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_contact';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_complain_id']))
			{
				$complain_id=$_REQUEST['del_complain_id'];
				$where=array("complain_id"=>$complain_id);
				$res=$this->delete_where('complain',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_complain';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_cate_id']))
			{
				$cate_id=$_REQUEST['del_cate_id'];
				$where=array("cate_id"=>$cate_id);
				$res=$this->delete_where('category',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_categories';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_appointment_id']))
			{
				$appointment_id=$_REQUEST['del_appointment_id'];
				$where=array("appointment_id"=>$appointment_id);
				$res=$this->delete_where('appointment',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_appointments';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_slot_id']))
			{
				$slot_id=$_REQUEST['del_slot_id'];
				$where=array("slot_id"=>$slot_id);
				$res=$this->delete_where('slots',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_appointment_slots';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_service_id']))
			{
				$service_id=$_REQUEST['del_service_id'];
				$where=array("service_id"=>$service_id);
				$res=$this->delete_where('services',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_services';
					</script>";
				}
			}
			
			if(isset($_REQUEST['del_Product_id']))
			{
				$Product_id=$_REQUEST['del_Product_id'];
				$where=array("Product_id"=>$Product_id);
				$res=$this->delete_where('product',$where);
				if($res)
				{
					echo "<script>
					alert('DELETE SUCESSS');
					window.location='manage_products';
					</script>";
				}
			}
			break;
			
			case '/status':
			
			if(isset($_REQUEST['status_Product_id']))
			{
				$Product_id=$_REQUEST['status_Product_id'];
				$where=array("Product_id"=>$Product_id);
				
				$select=$this->select_where('product',$where);
				$fetch=$select->fetch_object();
				
				$status=$fetch->status;
				
				if($status=="Out of stock")
				{
					$arr_data=array("status"=>"Instock");		
					$res=$this->update('product',$arr_data,$where);
					if($res)
					{
						echo "<script>
							alert('Instock success !');
							window.location='manage_products';
						</script>";
					}
				}
				else
				{
					$arr_data=array("status"=>"Out of stock");		
					$res=$this->update('product',$arr_data,$where);
					if($res)
					{
						echo "<script>
							alert('Out of stock success !');
							window.location='manage_products';
						</script>";
					}
				}
			}
			
			if(isset($_REQUEST['status_customer_id']))
			{
				$customer_id=$_REQUEST['status_customer_id'];
				$where=array("customer_id"=>$customer_id);
				
				$select=$this->select_where('customer',$where);
				$fetch=$select->fetch_object();
				
				$status=$fetch->status;
				
				if($status=="Block")
				{
					$arr_data=array("status"=>"Unblock");		
					$res=$this->update('customer',$arr_data,$where);
					if($res)
					{
						echo "<script>
							alert('Unblock success !');
							window.location='manage_customer';
						</script>";
					}
				}
				else
				{
					$arr_data=array("status"=>"Block");		
					$res=$this->update('customer',$arr_data,$where);
					if($res)
					{
						echo "<script>
							alert('Block success !');
							window.location='manage_customer';
						</script>";
					}
				}
			}
			
			
			break;
			
			default:
			include_once('pnf.php');
			break;
			
		}		
		
	}
	
}

$obj=new control;


?>