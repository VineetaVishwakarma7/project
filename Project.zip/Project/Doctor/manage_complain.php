﻿	<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
   include_once('header.php')
   ?>
   
   <?php
   if (isset($_SESSION['Doctor_id'])) {
    $Doctor_id=$_SESSION['Doctor_id'];
    $obj = new model;
    $comp_arr = $obj->select_where('complain', array("Doctor_id" => $Doctor_id));
} else {
    echo "Doctor ID not provided!";
}
   ?>
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Complain</h1>
                        
                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Complain
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>

                                            <th>Note</th>
                                            <th>Rate</th>
                                            <th>Customer name</th>
                                            <th>Doctor name</th>
                                            
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
										if(!empty($comp_arr))
										{
											foreach($comp_arr as $c)
											{
										?>
										<tr>

                                            <td><?php echo$c->Note?></td>
                                            <td><?php echo$c->Rate?></td>
                                            <td><?php echo$c->First_name?></td>
                                            <td><?php echo$c->Doctor_id?></td>
                                          
										
                                        </tr>
										<?php
											}
										}
										?>
										</tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>