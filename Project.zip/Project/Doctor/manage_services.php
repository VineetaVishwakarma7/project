﻿	<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
   include_once('header.php')
   ?>
   
   <?php
   if (isset($_SESSION['Doctor_id'])) {
    $Doctor_id=$_SESSION['Doctor_id'];
    $obj = new model;
    $serv_arr = $obj->select_where('services', array("Doctor_id" => $Doctor_id));
} else {
    echo "Doctor ID not provided!";
}
   ?>
   
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage service</h1>
                        
                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manage Service
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
										<th>Service_name</th>
                                            <th>Price</th>
                                            <th>Detail</th>
                                            <th align="center">Action</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
										<?php
										if(!empty($serv_arr))
											{
											foreach($serv_arr as $c)
											{
										?>						
                                        <tr>
                                            <td><?php echo $c['service_name']?></td>
                                            <td><?php echo $c['price']?></td>
                                            <td><?php echo $c['detail']?></td>        
                                        <td align="center">
										<a href="edit_service?edit_service_id=<?php echo $c['service_id']?>" class="btn btn-info">Edit</a>
										<a href="delete?del_service_id=<?php echo $c['service_id']?>" class="btn btn-danger">Delete</a>
										</td>
                                        </tr>
										<?php
										}
										}
										?>                                   
										</tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>