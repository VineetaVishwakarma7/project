﻿<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}	
   include_once('header.php')
   ?>      
	  <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Add Categories</h1>
                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                           Add categories
                        </div>
                        <div class="panel-body">
                            <form action="" method="post">
                                        <div class="form-group">
                                            <label>Enter Categories Name</label>
                                            <input name="cate_name" class="form-control" type="text">
                                        </div>
										
										<div class="form-group">
                                            <label>Upload Categories Image</label>
                                            <input name="cate_img" class="form-control" type="file">
                                        </div>
                                
                        		    <input type="submit" name="submit" value="Submit" class="btn btn-info">
                            </form>   	
                        </div>
                </div>
            </div>
    

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php
   include_once('footer.php')
   ?>