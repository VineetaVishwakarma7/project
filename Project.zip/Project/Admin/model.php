<?php
class model{
	
	public $conn="";
	function __construct()
	{
		$this->conn=new mysqli('localhost','root','','online_shop');
	}
	function select($tbl)
	{
		$sel="select * from $tbl";
		$run=$this->conn->query($sel);
		while($fetch=$run->fetch_object())
	
		{
			$arr[]=$fetch;
		}
		return $arr;
		
	}

	function select_where($tbl,$arr)
	{
		$sel="select * from $tbl where 1=1"; // query continue
		$i=0;
		$arr_key=array_keys($arr);
		$arr_value=array_values($arr);
		foreach($arr as $w)
		{
			$sel.=" and $arr_key[$i]='$arr_value[$i]'";
			$i++;
		}
		$run=$this->conn->query($sel);  // run on db
		return $run;
	}
	
	function insert($tbl,$arr)
	{
		$col_arr=array_keys($arr); // array("0"=>"name","1"=>"email","2"=>"message")
		$col=implode(",",$col_arr); // name,email,messa
		
		$value_arr=array_values($arr); // array("0"=>"vineeta","1"=>"vishwakarmavineeta03@gmail.com","2"=>"address plz")
		$value=implode("','",$value_arr); // 'vineeta','vishwakarmavineeta03@gmail.com','address plz'
		
		$ins="insert into $tbl($col) values('$value')";  // query
		$run=$this->conn->query($ins);  // run on db
		return $run;
	}
	function update($tbl,$arr,$where)
	{
		$col_arr=array_keys($arr); // array("0"=>"name","1"=>"email","2"=>"message")
		$val_arr=array_values($arr); // array("0"=>"name","1"=>"email","2"=>"message")
	
		$upd="update $tbl set ";
		$i=0;
		$count=count($arr);
		foreach($arr as $d)
		{
			if($count==$i+1)
			{
				$upd.=" $col_arr[$i]='$val_arr[$i]'";
			}
			else
			{
				$upd.=" $col_arr[$i]='$val_arr[$i]',";
				$i++;
			}
		}
		$upd.=" where 1=1"; // query continue
		$j=0;
		$warr_key=array_keys($where);
		$warr_value=array_values($where);
		foreach($where as $w)
		{
		echo	$upd.=" and $warr_key[$j]='$warr_value[$j]'";
			$j++;
		}
		$run=$this->conn->query($upd);  // run on db
		return $run;
		
	}
	function delete_where($tbl,$where)
	{
		$col_where=array_keys($where);
		$value_where=array_values($where);
		
		$del="delete from $tbl where 1=1";
		$i=0;
		foreach($where as $c)
		{
			$del.=" and $col_where[$i]=$value_where[$i]";
			$i++;
		}
		$run=$this->conn->query($del);
		return $run;
	}
}
$obj=new model;

?>