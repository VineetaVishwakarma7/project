﻿	<?php
	if(isset($_SESSION['Admin_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
   include_once('header.php')
   ?>
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage service</h1>
                        
                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manage Service
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Service_name</th>
                                            <th>Price</th>
                                            <th>Detail</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
										<?php
										if(!empty($serv_arr))
											{
											foreach($serv_arr as $c)
											{
										?>						
                                        <tr>
                                            <td><?php echo $c->service_name;?></td>
                                            <td><?php echo $c->price;?></td>  
                                            <td><?php echo $c->detail;?></td>  

                                        </tr>
										<?php
										}
										}
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>