<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Panel</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body> 
	<?php
	function active($currect_page){
	  $url_array =  explode('/', $_SERVER['REQUEST_URI']) ;
	  $url = end($url_array);  
	  if($currect_page == $url){
		  echo 'active'; //class name in css 
	  } 
	}
	?>

<div id="wrapper">
 <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard">Admin
            </div>

            <div class="header-right">
					
					<?php
					if(isset($_SESSION['Admin_id']))
					{
					?>
					<span class="text-body">|</span>
                    <a class="text-body px-3" href=""><i class="fa fa-envelope mr-2"></i><?php echo "Hi .. " . $_SESSION['Name']?></a>
					<span class="text-body">|</span>
                    <a class="text-body px-3" href="profile"><i class="fa fa-user mr-2"></i>Profile</a>
					<?php	
					}
					?>   
            </div>
        </nav>
<!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img">
                            <img src="assets/img/vineeta/dog.jpg" width="250px" class="img-thumbnail" />

                            <div class="inner-text">
                                
                            </div>
                        </div>


                    </li>


                    <li>
                        <a class="active-menu" href="Dashboard"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
						
                   
                           
						
                    <li>
                        <a href="#"><i class="fa fa-sign-in"></i>Doctor <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="add_doctor"><i class="fa fa-toggle-on"></i>Add Doctor</a>
                            </li>
                            <li>
                                <a href="manage_doctor"><i class="fa fa-toggle-on"></i>Manage Doctor</a>
                            </li>
                        </ul>
                    </li>
					<li>
                         <a href="manage_customer"><i class="fa fa-sign-in"></i>Manage Customer</a>
                     </li>
					
                    <li>
                        <a href="manage_services"><i class="fa fa-sign-in "></i>Manage services</a>
                    </li>
                     <li>
                        <a href="manage_products"><i class="fa fa-sign-in "></i>Manage products</a>
                    </li>
                   
                    <li>
                        <a href="manage_appointments"><i class="fa fa-sign-in "></i>Manage Appoinments</a>
                    </li>
					<li>
                        <a href="manage_appointment_slots"><i class="fa fa-sign-in "></i>Manage Appointments Slots</a>
                    </li>
                    
                    <li>
                        <a href="Complain"><i class="fa fa-sign-in "></i>Complain</a>
                    </li>

                    <li>
						
					
						<?php
                        if(isset($_SESSION['Admin_id']))
                        {
                        ?>
                        <a href="adminlogout" class="nav-item nav-link">Logout</a>
                        <?php   
                        }
                        else
                        {
                        ?>
                        <a href="index" class="nav-item nav-link <?php active('Admin_id')?>">Login</a>
                        <?php
                        }
                        ?>
                   
                    </li>
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
