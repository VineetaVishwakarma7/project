<?php

// Function to get available time slots
function getAvailableTimeSlots($date) {
    // You can replace this with logic to fetch available slots from the database
    // For simplicity, using a static array in this example
    $bookedSlots = getBookedSlots($date);
    $allSlots = ['10:00 AM', '11:00 AM', '12:00 PM', '1:00 PM', '2:00 PM', '3:00 PM'];

    // Filter out booked slots
    $availableSlots = array_diff($allSlots, $bookedSlots);

    return $availableSlots;
}

// Function to get booked time slots for a specific date
function getBookedSlots($date) {
    // You can replace this with logic to fetch booked slots from the database
    // For simplicity, using a static array in this example
    $bookedSlots = ['11:00 AM', '1:00 PM', '3:00 PM'];

    return $bookedSlots;
}

// Function to schedule an appointment
function scheduleAppointment($date, $time, $petName) {
    // You can replace this with logic to save the appointment in the database
    // For simplicity, appending to a text file in this example
    $appointmentInfo = "$date $time - $petName\n";
    file_put_contents('appointments.txt', $appointmentInfo, FILE_APPEND);

    // You may also want to send confirmation emails, update the database, etc.
}

// Example usage
$date = '2024-02-14';
$availableSlots = getAvailableTimeSlots($date);

if (!empty($availableSlots)) {
    // Display available time slots to the user
    echo "Available time slots for $date:\n";
    foreach ($availableSlots as $slot) {
        echo "$slot\n";
    }

    // Example scheduling an appointment
    $selectedTime = '12:00 PM';
    $petName = 'Fluffy';

    scheduleAppointment($date, $selectedTime, $petName);

    echo "Appointment scheduled for $date at $selectedTime for $petName\n";
} else {
    echo "No available time slots for $date\n";
}

?>
