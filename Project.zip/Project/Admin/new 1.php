case '/add_prescription':
			$cust_arr=$this->select('customer');
			if(isset($_REQUEST['submit']))
			{
				$Doctor_id=$_REQUEST['Doctor_id'];
				$customer_id=$_REQUEST['customer_id'];
				$Old_prescription=$_REQUEST['Old_prescription'];
				
				$arr_data=array("Old_prescription"=>$Old_prescription,"customer_id"=>$customer_id,"Doctor_id"=>$Doctor_id);
				
				$res=$this->insert('prescription',$arr_data);
				if($res)
				{
					echo "<script>
						alert('inquiry Subbmited success !');
					</script>";
				}
				else
				{
					echo "error";
				}	
					
			}
			include_once('add_prescription.php');
			break;
			
			
			
			
			
					 c.execute('''INSERT INTO appointments (slot_id, pet_owner_name, pet_name) VALUES (?, ?, ?)''', (slot_id, pet_owner_name, pet_name))
						conn.commit()
				$slots_id=$_REQUEST['slot_id']
				$Doctor_id =$_REQUEST['Doctor_id'];
				$Date=$_REQUEST['Date'];
				$Time=$_REQUEST['Time'];
				$day=$_REQUEST['day'];
				
				$arr_data=array("slot_id"=>$slot_id,"Doctor_id "=>$Doctor_id,"Date"=>$Date,"Time"=>$Time,"day"=>$day);
					
					$res=$this->insert('appointment',$arr_data);
					if($res)
					