﻿	﻿<?php
	if(isset($_SESSION['Admin_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
   include_once('header.php')
   ?>
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage products</h1>
                        
                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Manage Products
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
											<th>Product Img</th>
                                            <th>Product Name</th>
											<th>Category</th>
                                            <th>Price</th>
											<th align="center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

										<?php
										if(!empty($prod_arr))
											{
											foreach($prod_arr as $c)
											{
										?>						
                                        <tr>
											<td><img src="img/vineeta/<?php echo $c->p_img?>"width="50px"></td>
                                            <td><?php echo $c->Product_name;?></td>
                                            <td><?php echo $c->Product_category;?></td>
                                            <td><?php echo $c->Price;?></td>
   
										<td align="center">
										<a href="status?status_Product_id=<?php echo $c->Product_id ;?>" class="btn btn-primary"><?php echo $c->status;?></a>
										</td>
                                        </tr>
										<?php
										}
										}
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>