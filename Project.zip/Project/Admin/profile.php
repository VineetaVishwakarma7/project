<?php 
if(isset($_SESSION['Admin_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}



include_once('header.php');
 ?>
<div id="page-wrapper">
    <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Profile</h1>
                    </div>
                </div>    
				
            <div  style="padding: 12 400px;">
                <div class="team-item">
                   <img width="300px" src="img/vineeta/<?php echo $data->profile?>" alt="">
                     
                    <div class=" py-12">
                        <h4 class="text-uppercase"><?php echo $data->Name?></h4>
                        <p class="m-0">User Name : <?php echo $data->Username?></p>
						<p class="m-0">Mobile : <?php echo $data->Mobile?></p>
						
						
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- Team End -->