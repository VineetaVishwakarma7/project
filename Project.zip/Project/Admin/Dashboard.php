﻿<?php
	if(isset($_SESSION['Doctor_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}	
   include_once('header.php')
   ?>       
	   <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">DASHBOARD</h1>
                        
                    </div>
                </div>
                <!-- /. ROW  -->
                

                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">

                                <div id="reviews" class="carousel slide" data-ride="carousel">

                                    <div class="carousel-inner">
                                        <div class="item active">

                                            <div class="col-md-10 col-md-offset-1">

                                                <h4><i class="fa fa-quote-left"></i>Love of animals is a universal impulse, a common ground on which all of us may meet. By loving and understanding animals, perhaps we humans shall come to understand each other.We must remember that our actions towards animals reflect our humanity. It is our responsibility to be compassionate and kind.<i class="fa fa-quote-right"></i></h4>
                                                
                                                <h5 class="pull-right"><strong class="c-black">Vineeta Vishwakarma Parmar</strong></h5>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-10 col-md-offset-1">

                                                <h4><i class="fa fa-quote-left"></i>Love of animals is a universal impulse, a common ground on which all of us may meet. By loving and understanding animals, perhaps we humans shall come to understand each other.We must remember that our actions towards animals reflect our humanity. It is our responsibility to be compassionate and kind.<i class="fa fa-quote-right"></i></h4>
                                                <div class="user-img pull-right">
                                                    
                                                </div>
                                                <h5 class="pull-right"><strong class="c-black">Vineeta Vishwakarma</strong></h5>
                                            </div>

                                        </div>
                                        <div class="item">
                                            <div class="col-md-10 col-md-offset-1">

                                                <h4><i class="fa fa-quote-left"></i>Love of animals is a universal impulse, a common ground on which all of us may meet. By loving and understanding animals, perhaps we humans shall come to understand each other.We must remember that our actions towards animals reflect our humanity. It is our responsibility to be compassionate and kind. <i class="fa fa-quote-right"></i></h4>
                                                <div class="user-img pull-right">
                                                    
                                                </div>
                                                <h5 class="pull-right"><strong class="c-black">Vineeta Vishwakarma Parmar</strong></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <!--INDICATORS-->
                                    <ol class="carousel-indicators">
                                        <li data-target="#reviews" data-slide-to="0" class="active"></li>
                                        <li data-target="#reviews" data-slide-to="1"></li>
                                        <li data-target="#reviews" data-slide-to="2"></li>
                                    </ol>
                                    <!--PREVIUS-NEXT BUTTONS-->

                                </div>

                            </div>

                        </div>
                        <!-- /. ROW  -->
                        <hr />

                        <div class="panel panel-default">

                            <div id="carousel-example" class="carousel slide" data-ride="carousel" style="border: 5px solid #000;">

                                <div class="carousel-inner">
                                    <div class="item active">

                                        <img src="assets/img/slideshow/4.jpg" alt="">

                                    </div>
                                    <div class="item">
                                        <img src="assets/img/slideshow/9.jpeg" alt="" />

                                    </div>
                                    <div class="item">
                                        <img src="assets/img/slideshow/5.jpg" alt="" />

                                    </div>
                                </div>
                                <!--INDICATORS-->
                                <ol class="carousel-indicators">
                                    <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
                                    <li data-target="#carousel-example" data-slide-to="1"></li>
                                    <li data-target="#carousel-example" data-slide-to="2"></li>
                                </ol>
                                <!--PREVIUS-NEXT BUTTONS-->
                                <a class="left carousel-control" href="#carousel-example" data-slide="prev">
                                    <span class="glyphicon glyphicon-chevron-left"></span>
                                </a>
                                <a class="right carousel-control" href="#carousel-example" data-slide="next">
                                    <span class="glyphicon glyphicon-chevron-right"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    <div class="col-md-4">

                        <div class="panel panel-default">
                            <div class="panel-heading">
                                What our Doctor says...
                            </div>
                            <div class="panel-body" style="padding: 0px;">
                                <div class="chat-widget-main">


                                    <div class="chat-widget-left">
                                        Experience the Future of Healthcare Today.
                                    </div>
                                    <div class="chat-widget-name-left">
                                        <h4>Avani Prajapati</h4>
                                    </div>
                                    <div class="chat-widget-right">
                                        Your Partner in Health and Healing.
                                    </div>
                                    <div class="chat-widget-name-right">
                                        <h4>Kamesh Leuva </h4>
                                    </div>
                                    <div class="chat-widget-left">
                                        Healing Lives, One Patient at a Time.
                                    </div>
                                    <div class="chat-widget-name-left">
                                        <h4>Yatiksha Makwana</h4>
                                    </div>
                                    <div class="chat-widget-right">
                                        Experience the Difference of Patient-Centered Excellence.
                                    </div>
                                    <div class="chat-widget-name-right">
                                        <h4>Jatin Parmar</h4>
                                    </div>
                                </div>
                            </div>
                            
                        </div>


                    </div>
                    <!--/.Chat Panel End-->
                </div>
                <!-- /. ROW  -->


              
    <?php
   include_once('footer.php')
   ?>