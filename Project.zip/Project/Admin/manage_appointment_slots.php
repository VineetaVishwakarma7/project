﻿	<?php
	if(isset($_SESSION['Admin_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
   include_once('header.php')
   ?>
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage appointments slots</h1>
                        
                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Manage appointment slots  
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>slot_id</th>
											<th>Doctor_id</th>
                                            <th>Time</th>
											
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
										if(!empty($slot_arr))
										{
											foreach($slot_arr as $c)
											{
										?>
										<tr>
                                            <td><?php echo$c->slot_id?></td>
											<td><?php echo$c->Doctor_id?></td>
                                            <td><?php echo$c->Time?></td>
										
                                  </tr>
										<?php
											}
										}
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>