<?php
	if(isset($_SESSION['otp']))
	{
	}
	else
	{
		echo "<script>
				window.location='index';
			</script>";
	}
	include_once('header.php');
	?>
  
  <!-- Contact Start -->
  <div id="page-wrapper">
    <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Varification link</h1>
                    </div>
                </div>

            <div class="row">
                <div class="col-lg-12 mb-2">
                    <div class="contact-form bg-light mb-6" style="padding: 30px;">
                       <form action="" method="post" enctype="multipart/form-data">
                            <div class="row">
								<div class="col-6 form-group">
                                    <input type="text" name="otp" class="form-control p-4" placeholder="Enter OTP" required="required">
                                </div>
                          <div>
                                <input class="btn btn-primary py-3 px-5" name="submit" type="submit" value="Reset Password">
								
                            </div>
                        </form>
                    </div>
                </div>
          
            </div>
        </div>
    </div>
    <!-- Contact End -->


<?php
   include_once('footer.php')
   ?>