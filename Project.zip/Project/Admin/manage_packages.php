﻿	<?php
	if(isset($_SESSION['Admin_id']))
	{
		
	}
	else
	{
		echo "<script>
			window.location='index';
		</script>";
	}
}
?>

   include_once('header.php')
   ?>
		<div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage packages</h1>
                       
                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-6">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Manage Packages
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>package_id</th>
                                            <th>product_name</th>
											<th>Product_id</th>
                                            <th>Combo_offer</th>
											<th align="center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php
										if(!empty($pack_arr))
											{
											foreach($pack_arr as $c)
											{
										?>						
                                        <tr>
                                            <td><?php echo $c->package_id;?></td>
                                            <td><?php echo $c->product_name;?></td>
                                            <td><?php echo $c->Product_id;?></td>
                                            <td><?php echo $c->Combo_offer;?></td>
>

										<td align="center">
										<a href="#" class="btn btn-info">Edit</a>
										<a href="#" class="btn btn-danger">Delete</a>
										</td>
                                        </tr>
										<?php
										}
										}
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
					<!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    
  <?php
   include_once('footer.php')
   ?>